'use strict';

angular.module('app.services').service('hubService', ['$rootScope', 'webApi',
    function ($rootScope, webApi) {
        var _self = this;
        var hub = $.connection.globalHub;
        var listeners = [];

        this.start = function () {
            hub.connection.url = 'https://apideveloper.santander.cl/sancl/privado/account_recovery/v1/scj-emerix/signalr';
            hub.connection.start(function () {
                if (window.console) console.info('Push service started.');
            }).done(function () {
                console.log('SignalR connected, connection id = ' + $.connection.hub.id);
            }).fail(function (data) {
                console.log('SignalR failed to connect: ' + data);
            });

            hub.connection.error(function (error) {
                if (window.console) console.info(error);
            });

            hub.connection.stateChanged(function (change) {
                if (change.newState === $.signalR.connectionState.reconnecting) {
                    if (window.console) console.info('Push service re-connecting.');
                }
                else if (change.newState === $.signalR.connectionState.connected) {
                    if (window.console) console.info('Push service online.');
                }
                else if (change.newState === $.signalR.connectionState.disconnected) {
                    //hub.connection.start();
                    setTimeout(function () {
                        $.connection.hub.start();
                    }, 5000); // Restart connection after 5 seconds.
                };
            });

            //Broadcaste received messages
            hub.client.echo = function (message) {
                $rootScope.$broadcast(message.Action, message.Value);
            };

        };

        this.stop = function () {
            hub.connection.stop();
        };

    }]);
