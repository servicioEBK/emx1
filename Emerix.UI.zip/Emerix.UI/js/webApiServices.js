'use strict';
/* Objeto global para guardar las referencias a las funciones */
window.emerixAngJSGlobal = {};
/* webApi Services */
angular.module('app.services')
    .service('webApi', ['$http', function ($http) {
        window.emerixAngJSGlobal.webApi = this;
        var baseUrl = 'https://apideveloper.santander.cl/sancl/privado/account_recovery/v1/scj-emerix/';
        var SecurebaseUrl = 'https://apideveloper.santander.cl/sancl/privado/account_recovery/v1/scj-emerix/';

        this.getBaseUrl = function () {
            return baseUrl;
        }

        this.getSecureBaseUrl = function () {
            return SecurebaseUrl;
        }

        this.addEntity = function (name, entity, force) {
            force = force || false;
            if (this[name]) {
                if (force)
                    this[name] = entity;
            }
            else
                this[name] = entity;
        }

        this.security = {
            ValidateUser: function (credentials) {
                return $http.post(SecurebaseUrl + 'login/validateuser', credentials);
            },
            ValidateUserSso: function (ssoDto) {
                return $http.post(SecurebaseUrl + 'login/ValidateUserSso', ssoDto);
            },
            checkLicense: function () {
                return $http.get(baseUrl + 'login/CheckLicense');
            },
            getFunctionMenusUser: function (credentials) {
                return $http.post(baseUrl + 'login/getFunctionMenusUser', credentials);
            },
            authenticate: function (credentials) {

                return $http.post(SecurebaseUrl + 'login/authenticate', credentials);
            },
            authenticatUser: function (credentials) {

                return $http.post(SecurebaseUrl + 'login/authenticateUser', credentials);
            },
            GetDataAuthenticate: function (credentials) {

                return $http.post(SecurebaseUrl + 'login/getDataAuthenticate', credentials);
            },
            logout: function (credentials) {

                return $http.post(SecurebaseUrl + 'login/logout', credentials);
            },
            AuthenticateByJwt: function (credHash) {

                return $http.post(baseUrl + 'login/AuthenticateByJwt', credHash);
            },
            getLoginResources: function () {
                return $http.get(baseUrl + 'login/getLoginResources');
            },
            getAllLoginResources: function () {
                return $http.get(baseUrl + 'login/getAllLoginResources');
            },
            getAuthenticationMet: function () {
                return $http.get(baseUrl + 'login/getAuthenticationMet');
            },
            saveLoginResources: function (params) {
                return $http.post(baseUrl + 'login/saveLoginResources', params);
            },
            getDllProperties: function () {
                return $http.get(baseUrl + 'login/getDllProperties');
            },
            getDatabaseConnections: function () {
                return $http.get(baseUrl + 'login/getDatabaseConnections');
            },
            RememberSso: function (Jwt) {
                $http({
                    method: "POST",
                    url: (window.Emerix.appBaseUrl + "Home/RememberSso"),
                    dataType: 'json',
                    data: { cookie: Jwt },
                    headers: { "Content-Type": "application/json" }
                })
            }
            ,
            RemoveSso: function (Name) {
                $http({
                    method: "POST",
                    url: (window.Emerix.appBaseUrl + "Home/RemoveSso"),
                    dataType: 'json',
                    data: { cookieName: Name },
                    headers: { "Content-Type": "application/json" }
                })
            },
            Remember: function (Jwt) {
                $http({
                    method: "POST",
                    url: (window.Emerix.appBaseUrl + "Home/Remember"),
                    dataType: 'json',
                    data: { cookie: Jwt },
                    headers: { "Content-Type": "application/json" }
                })
            },
            Remove: function (Name) {
                $http({
                    method: "POST",
                    url: (window.Emerix.appBaseUrl + "Home/Remove"),
                    dataType: 'json',
                    data: { cookieName: Name },
                    headers: { "Content-Type": "application/json" }
                })
            },
            /**
             * Retorna la fecha en la que se debe renovar el token.
             * */
            getRefreshTokenDate: function () {
                return $http.get(SecurebaseUrl + 'login/getrefreshtokendate');
            },
            /**
             * Genera un nuevo token en base a uno v�lido.
             * @param {any} credentials Datos de la sesi�n.
             */
            refreshToken: function (credentials) {
                return $http.post(SecurebaseUrl + 'login/refreshtoken', credentials);
            }
        };

        this.export = {
            render: function (params) {
                return $http.post(baseUrl + 'export/render', params);
            },
            RenderFile: function (params) {
                return $http.post(baseUrl + 'export/renderFile', params, { responseType: 'arraybuffer' });
            },
            RenderQuery: function (params) {
                return $http.post(baseUrl + 'export/renderQuery', params, { responseType: 'arraybuffer' });
            }
        }

        this.concurrenceLocks = {
            tryLock: function (feature) {
                return $http.post(baseUrl + 'concurrencelock/tryLock', { lockKey: feature });
            },
            unlock: function (feature) {
                return $http.post(baseUrl + 'concurrencelock/unlock', { lockKey: feature });
            }
        };

        this.menus = {
            getMenu: function (menuRequestData) {
                return $http.post(baseUrl + 'menu/menu', menuRequestData);
            }
        };

        this.teamsbystrategystate = {
            getstrategystatemembers: function (params) {
                return $http.post(baseUrl + 'TeamsByStrategyState/StrategyStateMembersList', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'TeamsByStrategyState/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'TeamsByStrategyState/Remove', params);
            }
        }

        this.teamsbystage = {
            teamsbystagelist: function (params) {
                return $http.post(baseUrl + 'teamsbystage/TeamsByStageList', params);
            },
            teamsexcludedlist: function (params) {
                return $http.post(baseUrl + 'teamsbystage/TeamsExcludedList', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'teamsbystage/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'teamsbystage/Remove', params);
            }
        }

        this.diagnostics = {
            saveNavigationAudit: function (navigationAuditInfo) {
                return $http.post(baseUrl + 'diagnostics/saveNavigationAuditInfo', navigationAuditInfo);
            },
            getServerAudit: function (params) {
                return $http.post(baseUrl + 'diagnostics/getServerAudit', params);
            },
            getAccessAudit: function (params) {
                return $http.post(baseUrl + 'diagnostics/getAccAudit', params);
            },
            getAccessUsers: function (params) {
                return $http.post(baseUrl + 'diagnostics/GetAccUsers', params);
            },
            getAccessTeams: function (params) {
                return $http.post(baseUrl + 'diagnostics/getAccTeams', params);
            },
            getAccessProfiles: function (params) {
                return $http.post(baseUrl + 'diagnostics/getAccProfiles', params);
            },
            getAccessAuditpending: function (params) {
                return $http.post(baseUrl + 'diagnostics/getAccessAuditpending', params);
            },
            getNavAudit: function (params) {
                return $http.post(baseUrl + 'diagnostics/getNavAudit', params);
            },
            getChangeAudit: function (params) {
                return $http.post(baseUrl + 'diagnostics/getChangeAudit', params);
            },
            getAccessEntity: function (params) {
                return $http.post(baseUrl + 'diagnostics/getAccEntity', params);
            },

        };

        this.schemas = {
            getLoginSchemas: function (username) {
                return $http.get(baseUrl + 'schemas/getLoginSchemas/' + username);
            },
            getBusinessSchemas: function (username) {
                return $http.get(baseUrl + 'schemas/getBusinessSchemas/' + username);
            },
            getUserEnabledSchemas: function (username) {
                return $http.get(baseUrl + 'schemas/getUserEnabledSchemas?id=' + username);
            },
            getUserEnabledSchemasUs: function (username) {
                return $http.get(baseUrl + 'schemas/getUserEnabledSchemasUs?id=' + username);
            },
            getSchemas: function (username) {
                return $http.get(baseUrl + 'schemas/getschemas');
            },
            getSchema: function (username) {
                return $http.get(baseUrl + 'schemas/getschema/' + username);
            }
        };

        this.locks = {
            getLocks: function () {
                return $http.get(baseUrl + 'locks/getitems');
            },
            save: function (item) {
                return $http.post(baseUrl + 'locks/save', item);
            },
            remove: function (item) {
                return $http.post(baseUrl + 'locks/remove', item);
            },
            removeById: function (LockId) {
                return $http.post(baseUrl + 'locks/removeById', { Id: LockId });
            },
            removeAll: function () {
                return $http.post(baseUrl + 'locks/removeAll');
            },
            removeLocks: function (param) {
                return $http.post(baseUrl + 'locks/RemoveLocks', { Hour: param });
            }
        };

        this.resources = {
            getLabels: function (langKey) {
                return $http.get(baseUrl + 'labels/get/' + langKey);
            },
            getMessages: function (langKey) {
                return $http.get(baseUrl + 'messages/get/' + langKey);
            }
            //, getIcons: function () {
            //    return $http.get(baseUrl + 'icons/get/');
            //}
        };

        this.person = {
            addPhone: function (params) {
                return $http.post(baseUrl + 'phone', params);
            },
            getPersons: function (limit) {
                return $http.get(baseUrl + 'person/getpersons/' + limit);
            },
            getPerson: function (clientId) {
                return $http.get(baseUrl + 'person/get/' + clientId);
            },
            getPersonById: function (clientId) {
                return $http.get(baseUrl + 'person/getPersonById/' + clientId);
            },
            getPersonByClave: function (claveext) {
                return $http.get(baseUrl + 'person/GetByClave/' + claveext);
            },
            getDependencies: function (clientId) {
                return $http.get(baseUrl + 'person/getdependencies/' + clientId);
            },
            getPersonRecord: function (personId) {
                return $http.get(baseUrl + 'person/getpersonrecord/' + personId);
            },
            getPersonLinkages: function (personId) {
                return $http.get(baseUrl + 'person/getpersonlinkages/' + personId);
            },
            getLinkagePersonAccount: function (personId) {
                return $http.get(baseUrl + 'person/GetLinkagePersonAccount/' + personId);
            },
            GetLinkagePersonAccountFromVinc: function (personId) {
                return $http.get(baseUrl + 'person/GetLinkagePersonAccountFromVinc/' + personId);
            },
            getFiliatoryData: function (personId) {
                return $http.get(baseUrl + 'person/getfiliatorydata/' + personId);
            },
            getChanges: function (personId) {
                return $http.get(baseUrl + 'person/getwflchanges/' + personId);
            },
            getPersonChanges: function (params) {
                return $http.post(baseUrl + 'person/PostPersonChangesFilter', params);
            },
            getPersonChangesFiltered: function (params) {
                return $http.post(baseUrl + 'person/SearchPersonChangesById', { Identifier: params });
            },
            getDebts: function (personId) {
                return $http.get(baseUrl + 'person/getdebts/' + personId);
            },
            saveLinkageAccountPerson: function (params) {
                return $http.post(baseUrl + 'person/savelinkageaccountperson', params);
            },
            removeLinkageAccountPerson: function (params) {
                return $http.post(baseUrl + 'person/removelinkageaccountperson', params);
            },
            saveLinkagePersonPerson: function (params) {
                return $http.post(baseUrl + 'person/savelinkagepersonperson', params);
            },
            removeLinkagePersonPerson: function (params) {
                return $http.post(baseUrl + 'person/removelinkagepersonperson', params);
            },
            searchPerson: function (params) {
                return $http.post(baseUrl + 'person/searchperson', { Search: params });
            },
            getIndicators: function (personId) {
                return $http.get(baseUrl + 'person/getIndicators/' + personId);
            },
            GetIndicatorsExtended: function (item) {
                return $http.post(baseUrl + 'person/GetIndicatorsExtended/', item);
            },
            getDebtInformation: function (personId) {
                return $http.get(baseUrl + 'person/getDebtInformation/' + personId);
            },
            getDebtInformationScore: function (personId) {
                return $http.get(baseUrl + 'person/getDebtInformationScore/' + personId);
            },
            getCoOwnersByPersonId: function (personId) {
                return $http.get(baseUrl + 'person/GetCoOwnersByPersonId/?personId=' + personId);
            }
        };

        this.personphoto = {
            getPersonPhoto: function (Id) {
                return $http.get(baseUrl + 'personphoto/get/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'personphoto/save', params);
            },
            getByPerson: function (Id) {
                return $http.get(baseUrl + 'personphoto/GetByPerson/' + Id);
            }
        };


        this.linkageAccountPersonTypes = {
            list: function () {
                return $http.get(baseUrl + 'linkageAccountPersonTypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'linkageAccountPersonTypes/save', params);
            }
        };

        this.linkageAccountAccount = {
            list: function () {
                return $http.get(baseUrl + 'linkageAccountAccount/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'linkageAccountAccount/save', params);
            }
        };

        this.linkagePersonPersonTypes = {
            list: function () {
                return $http.get(baseUrl + 'linkagePersonPersonTypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'linkagePersonPersonTypes/save', params);
            }
        };

        this.account = {
            getAccounts: function (clientId) {
                return $http.get(baseUrl + 'accounts/getaccounts/' + clientId);
            },
            getAccountsPaginated: function (id) {
                return $http.get(baseUrl + 'accounts/getaccountspaginatedbyperson/' + id);
            },
            getAccountFiltered: function (id) {
                return $http.get(baseUrl + 'accounts/searchaccountbyid/' + id);
            },
            getAccountsNumbers: function (params) {
                return $http.post(baseUrl + 'accounts/postaccountsfilter', params);
            },
            getDynaAccountRecords: function (id, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/runbyid', id);
            },
            getPayments: function (accountId) {
                return $http.get(baseUrl + 'payments/getpayments/' + accountId);
            },
            getPaymentsResources: function (accountId) {
                return $http.get(baseUrl + 'payments/getpaymentsresources/' + accountId);
            },
            getAccountRecord: function (accountId) {
                return $http.get(baseUrl + 'accounts/getaccountrecord/' + accountId);
            },
            getAccountRecords: function (personId) {
                return $http.get(baseUrl + 'accounts/getaccountrecords/' + personId);
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'accounts/getdependencies/');
            },
            get: function (id) {
                return $http.get(baseUrl + 'accounts/get/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'accounts/save', params);
            },
            getAccountFilterView: function (params) {
                return $http.post(baseUrl + 'accounts/postaccountfilterview', params);
            },
            /**
             * Retorna una página de los datos de las cuentas de la persona.
             * @param {number} personId Id de la persona.
             * @param {string} searchString Filtro de búsqueda.
             * @param {number} pageNumber Número de página.
             * @param {number} pageSize Cantidad de cuentas por página.
             */
            getPaginatedAccounts: function (personId, searchString, pageNumber, pageSize) {
                return $http.get(baseUrl +
                    'accounts/getpaginatedaccounts' +
                    '?personId=' + (!!personId ? personId : -1) +
                    '&searchString=' + (!!searchString ? searchString : '') +
                    '&pageNumber=' + (!!pageNumber ? pageNumber : 1) +
                    '&pageSize=' + (!!pageSize ? pageSize : 10));
            }
        };

        this.payments = {
            getItems: function (personId) {
                return $http.get(baseUrl + 'payments/getpersonpayments/' + personId);
            }
        };

        this.paymentTypes = {
            getPaymentTypes: function () {
                return $http.get(baseUrl + 'paymenttypes/getpaymenttypes');
            }
            , getPaymentType: function (id) {
                return $http.get(baseUrl + 'paymenttypes/getpaymenttype/' + id);
            }
            , save: function (params) {
                return $http.post(baseUrl + 'paymenttypes/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'paymenttypes/remove', params);
            }
        }
        this.parameterValues = {
            getParametersTree: function (id) {
                return $http.get(baseUrl + 'parametervaluesonworkflow/getparameterstree/' + id);
            }
            , save: function (params) {
                return $http.post(baseUrl + 'parametervaluesonworkflow/save', params);
            }
            , delete: function (params) {
                return $http.post(baseUrl + 'parametervaluesonworkflow/delete', params);
            }
        }

        this.paybranchTypes = {
            getPaybranchTypes: function () {
                return $http.get(baseUrl + 'paybranchtypes/getpaybranchs');
            }
            , getPaybranchType: function (id) {
                return $http.get(baseUrl + 'paybranchtypes/getpaybranch/' + id);
            }
            , save: function (params) {
                return $http.post(baseUrl + 'paybranchtypes/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'paybranchtypes/remove', params);
            }
            , GetItemsPage: function (params) {
                return $http.post(baseUrl + 'paybranchtypes/GetItemsPage', params);
            }
        }

        this.searchEngine = {
            getPersonsFilter: function (params) {
                return $http.post(baseUrl + 'personsearch/postpersonsfilter', params);
            }
        }

        this.phone = {
            getItem: function (phoneId) {
                return $http.get(baseUrl + 'phone/get/' + phoneId);
            },
            getBestRankedPhone: function (clientId) {
                return $http.get(baseUrl + 'phone/getbestrankedphone/' + clientId);
            },
            getItems: function (personId) {
                return $http.get(baseUrl + 'phone/getphones/' + personId);
            },
            getPhones: function (personId) {
                return $http.get(baseUrl + 'phone/getphones/' + personId);
            },
            getDependencies: function (personId) {
                return $http.get(baseUrl + 'phone/getdependencies/' + personId);
            },
            save: function (phone) {
                return $http.post(baseUrl + 'phone/save', phone);
            },
            remove: function (phone) {
                return $http.post(baseUrl + 'phone/remove', phone);
            },
            saveFiliationState: function (params) {
                return $http.post(baseUrl + 'phone/savefiliationstate', params);
            }
        };

        this.phoneTypes = {
            getPhoneTypes: function () {
                return $http.get(baseUrl + 'phonetypes/getPhoneTypes');
            }
            , getPhoneType: function (Id) {
                return $http.get(baseUrl + 'phonetypes/getPhoneType/' + Id);
            }
            , save: function (params) {
                return $http.post(baseUrl + 'phonetypes/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'phonetypes/remove', params);
            }
        }

        this.address = {
            getItem: function (addressId) {
                return $http.get(baseUrl + 'address/get/' + addressId);
            },
            getDependencies: function (personId) {
                return $http.get(baseUrl + 'address/getdependencies/' + personId);
            },
            getPrimaries: function (clientIds) {
                return $http.get(baseUrl + 'address/getprimaries/' + clientIds);
            },
            getTypes: function () {
                return $http.get(baseUrl + 'addresstypes/getitems');
            },
            getItemsDomByUser: function () {
                return $http.get(baseUrl + 'address/getitemsdombyuser/');
            },
            getType: function (typeId) {
                return $http.get(baseUrl + 'address/gettype/' + typeId);
            },
            getItems: function (clientId) {
                return $http.get(baseUrl + 'address/getitems/' + clientId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'address/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'address/remove', params);
            },
            saveFiliationState: function (params) {
                return $http.post(baseUrl + 'address/savefiliationstate', params);
            }
        }

        this.addressTypes = {
            getAddressType: function (id) {
                return $http.get(baseUrl + 'addresstypes/getitem/' + id);
            },
            getAddressTypes: function () {
                return $http.get(baseUrl + 'addresstypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'addresstypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'addresstypes/remove', params);
            },
            GetItemsPage: function (params) {
                return $http.post(baseUrl + 'addresstypes/GetItemsPage', params);
            }
        }

        this.provinces = {
            get: function (provinceId) {
                return $http.get(baseUrl + 'province/get/' + provinceId);
            }
            , getItems: function () {
                return $http.get(baseUrl + 'province/getitems');
            }
            , getProvinces: function (countryId) {
                return $http.get(baseUrl + 'province/getprovinces/' + countryId);
            }
            , getProvinceNames: function (id) {
                return $http.get(baseUrl + 'province/getprovincenames/' + id);
            }
            , getDependencies: function () {
                return $http.get(baseUrl + 'province/getdependencies');
            }
            , save: function (params) {
                return $http.post(baseUrl + 'province/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'province/remove', params);
            }
        }

        this.locations = {
            get: function (localityId) {
                return $http.get(baseUrl + 'locality/get/' + localityId);
            }
            , getItems: function () {
                return $http.get(baseUrl + 'locality/getitems');
            }
            , getLocations: function (provinceId) {
                return $http.get(baseUrl + 'locality/GetLocalities/' + provinceId);
            }
            , getDependencies: function () {
                return $http.get(baseUrl + 'locality/getdependencies');
            }
            , getLocalityNames: function (id) {
                return $http.get(baseUrl + 'locality/getlocalitynames/' + id);
            }
            , save: function (params) {
                return $http.post(baseUrl + 'locality/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'locality/remove', params);
            }
            , getLocationsPage: function (params) {
                return $http.post(baseUrl + 'locality/GetLocalitiesPage', params);
            }
        }

        this.countrys = {
            getCountrys: function () {
                return $http.get(baseUrl + 'countrys/getcountrys/');
            },
            getCountry: function (countryId) {
                return $http.get(baseUrl + 'countrys/getcountry/' + countryId);
            },
            getCountryNames: function () {
                return $http.get(baseUrl + 'countrys/getcountrynames')
            },
            save: function (params) {
                return $http.post(baseUrl + 'countrys/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'countrys/remove', params);
            }
        }

        this.filiationStates = {
            getFiliationStates: function () {
                return $http.get(baseUrl + 'filiationstates/getfiliationstates/');
            },
            getByFiliationType: function (Code) {
                return $http.get(baseUrl + 'filiationstates/GetByFiliationType/' + Code);
            },
            save: function (params) {
                return $http.post(baseUrl + 'filiationstates/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'filiationstates/remove', params);
            }
        }

        this.filiationTypes = {
            getTypes: function () {
                return $http.get(baseUrl + 'filiationtypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'filiationtypes/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'filiationtypes/remove', params);
            }
        }

        this.personMaritalStatus = {
            getItems: function () {
                return $http.get(baseUrl + 'PersonMaritalStatus/GetItems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'PersonMaritalStatus/GetItem/' + Id)
            },
            save: function (params) {
                return $http.post(baseUrl + 'PersonMaritalStatus/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'PersonMaritalStatus/Remove', params);
            }
        }

        this.personClasification = {
            getItems: function () {
                return $http.get(baseUrl + 'PersonClasification/GetItems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'PersonClasification/GetItem/' + Id)
            },
            save: function (params) {
                return $http.post(baseUrl + 'PersonClasification/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'PersonClasification/Remove', params);
            }
        }

        this.personActivity = {
            getItems: function () {
                return $http.get(baseUrl + 'PersonActivity/GetItems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'PersonActivity/GetItem/' + Id)
            },
            save: function (params) {
                return $http.post(baseUrl + 'PersonActivity/Save', params)
            },
            remove: function (params) {
                return $http.post(baseUrl + 'PersonActivity/Remove', params);
            },
            getItemsPage: function (params) {
                return $http.post(baseUrl + 'PersonActivity/GetItemsPage', params);
            }
        }

        this.personTaxCondition = {
            getItems: function () {
                return $http.get(baseUrl + 'PersonTaxCondition/GetItems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'PersonTaxCondition/GetItem/' + Id)
            },
            save: function (params) {
                return $http.post(baseUrl + 'PersonTaxCondition/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'PersonTaxCondition/Remove', params);
            }
        }

        this.mailTypes = {
            getMailTypes: function () {
                return $http.get(baseUrl + 'mailtypes/getmailtypes/');
            },
            getMailType: function (Id) {
                return $http.get(baseUrl + 'mailtypes/getmailtype/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'mailtypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'mailtypes/remove', params);
            }
        }

        this.mail = {
            getItems: function (clientId) {
                return $http.get(baseUrl + 'mail/getmailsperson/' + clientId);
            },
            getItem: function (mailId) {
                return $http.get(baseUrl + 'mail/get/' + mailId)
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'mail/getdependencies');
            },
            getMailDependencies: function (personId) {
                return $http.get(baseUrl + 'mail/getmaildependencies/' + personId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'mail/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'mail/remove', params);
            },
            saveFiliationState: function (params) {
                return $http.post(baseUrl + 'mail/savefiliationstate', params);
            }
        }

        this.document = {
            getItems: function (clientId) {
                return $http.get(baseUrl + 'document/getdocumentsperson/' + clientId);
            },
            getItem: function (documentId) {
                return $http.get(baseUrl + 'document/get/' + documentId);
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'document/getdependencies');
            },
            save: function (params) {
                return $http.post(baseUrl + 'document/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'document/remove', params);
            },
            saveFiliationState: function (params) {
                return $http.post(baseUrl + 'document/savefiliationstate', params);
            }
        }

        this.documentTypes = {
            getDocumentTypes: function () {
                return $http.get(baseUrl + 'documenttypes/getdocumenttypes/');
            },
            getDocumentType: function (Id) {
                return $http.get(baseUrl + 'documenttypes/getdocumenttype/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'documenttypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'documenttypes/remove', params);
            }
        }

        this.socialNetworks = {
            getItems: function (personId) {
                return $http.get(baseUrl + 'socialnetworks/getsocialnetworks/' + personId);
            },
            getItem: function (socialNetworkId) {
                return $http.get(baseUrl + 'socialnetworks/getsocialnetwork/' + socialNetworkId);
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'socialnetworks/getdependencies');
            },
            save: function (params) {
                return $http.post(baseUrl + 'socialnetworks/savesocialnetwork', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'socialnetworks/removesocialnetwork', params);
            },
            saveFiliationState: function (params) {
                return $http.post(baseUrl + 'socialnetworks/savefiliationstate', params);
            }
        }

        this.socialNetworkTypes = {
            getSocialNetworkTypesView: function () {
                return $http.get(baseUrl + 'metsocialnetworktypes/getsocialnetworktypesview/');
            },
            getSocialNetworkTypes: function () {
                return $http.get(baseUrl + 'metsocialnetworktypes/getsocialnetworktypes/');
            },
            getSocialNetworkType: function (id) {
                return $http.get(baseUrl + 'metsocialnetworktypes/getsocialnetworktypes/' + id);
            },
            getSocialNetworkTypeById: function (id) {
                return $http.get(baseUrl + 'metsocialnetworktypes/GetSocialNetworkTypeById/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'metsocialnetworktypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'metsocialnetworktypes/remove', params);
            },
        }

        this.documents = {
            merge: function (filter) {
                return $http.post(baseUrl + 'documents/merge', filter);
            },
            generateDocument: function (data) {
                return $http.post(baseUrl + 'documents/generateDocument', data);
            }
        }
        this.parameter = {
            installation: function () {
                return $http.get(baseUrl + 'instalation/getparams/');
            },
            getItems: function () {
                return $http.get(baseUrl + 'instalation/GetItems/');
            },
            getParameters: function () {
                return $http.get(baseUrl + 'MetParameters/GetItems/');
            },
            getParameter: function (parameterId) {
                return $http.get(baseUrl + 'MetParameters/GetItem/' + parameterId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'MetParameters/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'MetParameters/remove', params);
            },
            paramInUse: function (code) {
                return $http.get(baseUrl + 'MetParameters/GetParamInUse/' + code);
            },
            getLayoutParameters: function () {
                return $http.get(baseUrl + 'MetParameters/GetLayoutParameters/');
            },
            /**
             * Devuelve los ids de funciones asociadas al par�metro, cuyo id se proporciona.
             * @param {number} parameterId Id del par�metro.
             */
            getFunctionsByParameter: function (parameterId) {
                return $http.get(baseUrl +
                    'metparameters/getfunctionsbyparameter' +
                    '?parameterId=' + parameterId);
            }
        }

        this.parameterGroups = {
            getParameterGroups: function () {
                return $http.get(baseUrl + 'parametergroup/getparametergroups/');
            },
            getParameterGroupsNames: function () {
                return $http.get(baseUrl + 'parametergroup/getparametergroupsNames/');
            },
            getParameterGroup: function (parameterId) {
                return $http.get(baseUrl + 'parametergroup/getparameter/' + parameterId)
            },
            save: function (params) {
                return $http.post(baseUrl + 'parametergroup/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'parametergroup/remove', params);
            }
        }

        this.cruds = {
            getPhone_type: function () {
                return $http.get(baseUrl + 'phonetypes/');
            }
        }

        this.dashboard = {
            getResources: function (param) {
                return $http.post(baseUrl + 'dashboard/getresources/', param);
            },
            GetDebtsValues: function (param) {
                return $http.post(baseUrl + 'dashboard/GetDebtsValues/', param);
            },
            getCampainResources: function (param) {
                return $http.post(baseUrl + 'dashboard/getCampainResources/', param)
            },
            getPromiseResources: function (param) {
                return $http.post(baseUrl + 'dashboard/getPromiseResources/', param)

            },
            getActionResources: function (param) {
                return $http.post(baseUrl + 'dashboard/getActionResources/', param)

            },
            getCampaignStatistics: function () {
                return $http.get(baseUrl + 'dashboard/getcampaignstatistics/');
            }
        }

        this.managementRecord = {
            getResources: function (clientId) {
                return $http.get(baseUrl + 'management/getresources/' + clientId);
            },
            getActions: function (clientId) {
                return $http.get(baseUrl + 'management/getactions/' + clientId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'management/saveaction', params);
            },
            getSobs: function (param) {
                return $http.post(baseUrl + 'management/retrievemanagement', param);
            },
            getSobActionsPending: function (param) {
                return $http.post(baseUrl + 'management/retrievemanagementactionpending', param);
            },
            /**
             * Retorna el objeto pendiente por campa�a.
             * Tiene en cuenta el scope y los datos del usuario logueado.
             * @param {number} manualCampaignId Id de campa�a manual.
             * @param {number} personId Id de persona.
             * @param {number} objectId Id de objeto.
             */
            getManagementObjectPendingFromCampaign: function (manualCampaignId, personId, objectId) {
                return $http.get(baseUrl +
                    'management/getmanagementobjectpendingfromcampaign' +
                    '?manualCampaignId=' + (!!manualCampaignId ? manualCampaignId : -1) +
                    '&personId=' + (!!personId ? personId : -1) +
                    '&objectId=' + (!!objectId ? objectId : -1));
            },
            getSobActions: function (param) {
                return $http.post(baseUrl + 'management/retrievemanagementaction', param);
            },
            getAllSobActions: function () {
                return $http.get(baseUrl + 'management/getallmanagementactions');
            },
            getSobEvents: function (param) {
                return $http.post(baseUrl + 'management/retrievemanagementevent', param);
            },
            getSobAlarms: function (param) {
                return $http.post(baseUrl + 'management/retrievemanagementalarm', param);
            },
            getFilterSegmentByGroup: function (param) {
                return $http.post(baseUrl + 'management/GetFilterSegmentByGroup', param);
            },
            getFirstByCampaign: function (param) {
                return $http.get(baseUrl + 'management/getmanagefirstbycampaign/' + param);
            },
            getActionsByCampaign: function (param) {
                return $http.get(baseUrl + 'management/getitemsbycampaign/' + param);
            },
            getFirstAtAll: function (param) {
                return $http.get(baseUrl + 'management/getmanagefirstatall/' + param);
            },
            lockCampaignPerson: function (param) {
                return $http.get(baseUrl + 'management/getLockCampaignPerson/' + param);
            },
            unlockCampaignPerson: function (param) {
                return $http.get(baseUrl + 'management/getunlockcampaignperson/' + param);
            },
            /**
             * Retorna los objetos de la campaña que han sido asignados a un usuario, equipo o agente.
             * @param {number} pageNumber Número de página.
             * @param {number} pageSize Cantidad de registros por página.
             * @param {number} manualCampaignId Id de campaña manual.
             * @param {string} allocationMethodCode Filtro por código de método de asignación.
             * @param {string} allocationTypeCode Filtro por código de tipo de asignación.
             * @param {number} assignedId Id de asignado (usuario, equipo, agente, etc., según tipo de asignación).
             */
            getAssignedByCampaign: function (
                pageNumber, pageSize, manualCampaignId, allocationMethodCode, allocationTypeCode, assignedId
            ) {
                return $http.get(baseUrl + 'management/getassignedbycampaign' +
                    '?pageNumber=' + (!!pageNumber ? pageNumber : 1) +
                    '&pageSize=' + (!!pageSize ? pageSize : 10) +
                    '&manualCampaignId=' + (!!manualCampaignId ? manualCampaignId : -1) +
                    '&allocationMethodCode=' + (!!allocationMethodCode ? allocationMethodCode : '') +
                    '&allocationTypeCode=' + (!!allocationTypeCode ? allocationTypeCode : '') +
                    '&assignedId=' + (!!assignedId ? assignedId : ''));
            }
        }

        this.actionMessages = {
            getItems: function (id) {
                return $http.get(baseUrl + 'actionmessages/getitems/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'actionmessages/save', params);
            },
            markAsRead: function (id) {
                var param = { Id: id };
                return $http.post(baseUrl + 'actionmessages/CheckEmailAsRead', param);
            },
            checkMessage: function (params) {
                return $http.post(baseUrl + 'MessagesNotifications/CheckNewNovelty', params);

            }
        }
        this.MessagesByAction = {
            GetItemsPage: function (params) {
                return $http.post(baseUrl + 'MessagesByAction/GetItemsPage', params);
            },
            GetItem: function (id) {
                return $http.get(baseUrl + 'MessagesByAction/GetItem/' + id);
            },
            GetItems: function (params) {
                return $http.get(baseUrl + 'MessagesByAction/GetItems');
            }
        }

        this.actions = {
            getItem: function (id) {
                return $http.get(baseUrl + 'actions/getitem/' + id);
            },
            getItems: function (id) {
                return $http.get(baseUrl + 'actions/getitems/' + id);
            },
            retrieve: function (params) {
                return $http.post(baseUrl + 'actions/retrieveactions', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'actions/save', params);
            },
            saveWithForm: function (params) {
                return $http.post(baseUrl + 'actions/SaveWithForm', params);
            },
            remove: function (id) {
                return $http.get(baseUrl + 'actions/remove/' + id);
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'actions/getdependencies/');
            },
            getReportDependencies: function () {
                return $http.get(baseUrl + 'actions/GetReportDependencies/');
            },
            getDependenciesByUser: function () {
                return $http.get(baseUrl + 'actions/getdependenciesbyuser/');
            },
            closeConversation: function (params) {
                return $http.post(baseUrl + 'actions/closeconversation', params);

            },
            retrieveCoowners: function (params) {
                return $http.post(baseUrl + 'actions/RetrieveLastActions', params);
            },
            getItemsPaginated: function (params) {
                return $http.post(baseUrl + 'actions/getitemspaginated', params);
            },
            getAllItems: function (params) {
                return $http.post(baseUrl + 'actions/getallitems', params);
            },
            getHistGestCoOwner: function (id) {
                return $http.get(baseUrl + 'actions/GetHistGestCoOwner/' + id);
            },
            /**
             * Guarda una acción con formulario para múltiples objetos de una campaña.
             * @param {any} actionData
             * Datos de la acción a cargar.
             * @param {Array<number>} objectsIds
             * Ids de objetos sobre los que se cargará la acción.
             * @param {boolean} applyToAllObjectsInCampaign
             * Indica si la acción se debe cargar sobre todos los objetos de la campaña.
             */
            saveMultiple: function (actionData, objectsIds, applyToAllObjectsInCampaign) {
                var actionMultiple = !!actionData ? angular.copy(actionData) : {};
                actionMultiple.ObjectsIds = objectsIds;
                actionMultiple.ApplyToAllObjectsInCampaign = applyToAllObjectsInCampaign;

                return $http.post(baseUrl + 'actions/savemultiple', actionMultiple);
            }
        }

        this.actionPersonSearch = {
            getActionPersons: function (params) {
                return $http.post(baseUrl + 'actionpersonsearch/getactionpersons', params);
            }
        };

        this.actionTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'actiontypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'actiontypes/getitems/');
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'actiontypes/getdependencies/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'actiontypes/save', params);
            },
            saveWithConsequents: function (params) {
                return $http.post(baseUrl + 'actiontypes/savewithconsequents', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'actiontypes/remove', params);
            },
            getWorkflowTypeItems: function (params) {
                return $http.post(baseUrl + 'actiontypes/workflowtypeitems', { Code: params });
            },
            cloneWithConsequents: function (params) {
                return $http.post(baseUrl + 'actiontypes/clonewithconsequents', params);
            },
            /**
             * Clona un tipo de acci�n.
             * @param {any} actionType Datos del tipo de acci�n.
             */
            clone: function (actionType) {
                return $http.post(baseUrl + 'actiontypes/clone', actionType);
            },
            validateactionTypesWithActions: function (param) {
                return $http.post(baseUrl + 'actiontypes/validateActions', param);
            },
            /**
             * Retorna los consecuentes asociados al tipo de acci�n.
             * @param {number} actionTypeId Id de tipo de acci�n.
             */
            getConsequents: function (actionTypeId) {
                return $http.get(baseUrl +
                    'actiontypes/getconsequents' +
                    '?actionTypeId=' + (!!actionTypeId ? actionTypeId : -1));
            },
            /**
             * Retorna los tipos de acción, correspondientes al tipo de worflow.
             * @param {string} workflowTypeCode Código del tipo de workflow.
             */
            getGroups: function (workflowTypeCode) {
                return $http.get(baseUrl +
                    'actiontypes/getgroups' +
                    '?workflowTypeCode=' + (!!workflowTypeCode ? workflowTypeCode : ''));
            },
            /**
             * Retorna todos los tipos de acción pertenecientes al grupo y workflow.
             * Se filtra por estrategia (y estado), en caso de que se envíen los valores.
             * @param {string} actionGroup Grupo de tipo de acción.
             * @param {string} workflowTypeCode Código de tipo de workflow.
             * @param {number} strategyId Id de la estratégia.
             * @param {number} stateId Id del estado
             */
            getItemsByGroup: function (actionGroup, workflowTypeCode, strategyId, stateId) {
                return $http.get(baseUrl +
                    'actiontypes/getitemsbygroup' +
                    '?actionGroup=' + (!!actionGroup ? actionGroup : '') +
                    '&workflowTypeCode=' + (!!workflowTypeCode ? workflowTypeCode : '') +
                    '&strategyId=' + (!!strategyId ? strategyId : '') +
                    '&stateId=' + (!!stateId ? stateId : ''));
            },
            /**
             * Retorna los tipos de acción cuyos ids se proporcionan.
             * @param {Array<number>} actionTypeIds
             */
            getItemsByIdList: function (actionTypeIds) {
                var url = baseUrl + 'actiontypes/getitemsbyidlist';
                var ids = !!actionTypeIds && !!actionTypeIds.length > 0
                    ? actionTypeIds : [-1];

                for (var i = 0; i < ids.length; i++) {
                    url += i == 0 ? '?' : '&';
                    url += 'ids=' + ids[i];
                }

                return $http.get(url);
            },
            GetItemsFiliationByActionType: function (id) {
                return $http.get(baseUrl + 'actiontypes/GetItemsFiliationByActionType/' + id);
            }
        }

        this.responseTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'responsetypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'responsetypes/getitems/');
            },
            getActionTypeItems: function (actionTypeId) {
                return $http.get(baseUrl + 'responsetypes/getactiontypeitems/' + actionTypeId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'responsetypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'responsetypes/remove', params);
            },
            saveWithConsequents: function (params) {
                return $http.post(baseUrl + 'responsetypes/savewithconsequents', params);
            }
        }

        this.eventResponseTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'eventresponsetypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'eventresponsetypes/getitems/');
            },
            getEventTypeItems: function (actionTypeId) {
                return $http.get(baseUrl + 'eventresponsetypes/geteventtypeitems/' + actionTypeId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'eventresponsetypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'eventresponsetypes/remove', params);
            }
        }

        this.events = {
            getItems: function (id) {
                return $http.get(baseUrl + 'events/getitems/' + id);
            },
            getStatusInfo: function (id) {
                return $http.get(baseUrl + 'events/getstatusinfo/' + id);
            },
            getHistGestCoOwner: function (id) {
                return $http.get(baseUrl + 'events/GetHistGestCoOwner/' + id);
            },
            getItemsPaginated: function (params) {
                return $http.post(baseUrl + 'events/getitemspaginated', params);
            },
            getAllItems: function (params) {
                return $http.post(baseUrl + 'events/getallitems', params);
            },
        }

        this.promiseStates = {
            getItem: function (id) {
                return $http.get(baseUrl + 'promiseStates/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'promiseStates/getitems/');
            }
        }

        this.clientRecord = {
            getDependencies: function (clientId) {
                return $http.get(baseUrl + 'clientrecord/getdependencies/' + clientId);
            },

            /**
             * Devuelve las 'pesta�as de gesti�n', que tienen la informaci�n de
             * la ficha de gesti�n de los objetos de la persona.
             *
             * @param {number} personId Id de la persona.
             */
            getManagementTabs: function (personId) {
                return $http.get(baseUrl + 'clientrecord/getmanagementtabs?personId=' + personId);
            }
        }

        this.taskList = {
            getTaskList: function () {
                return $http.get(baseUrl + 'tasklist/gettasklist/');
            },
            getTaskListPortfolio: function (portfolioId) {
                return $http.get(baseUrl + 'tasklist/gettasklist/' + portfolioId);
            },
            getStagesTree: function (kitId) {
                return $http.get(baseUrl + 'tasklist/getstagestree/' + kitId);
            }
        }

        this.depuration = {
            getItem: function (id) {
                return $http.get(baseUrl + 'depuration/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'depuration/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'depuration/save', params);
            }
        }
        this.LinkActionType = {
            SaveAllStates: function (params) {
                return $http.post(baseUrl + 'LinkAction/SaveAllStates', params);
            },
            Remove: function (params) {
                return $http.post(baseUrl + 'LinkAction/Remove', params);
            },
            GetItemsbyStrategy: function (id) {
                return $http.get(baseUrl + 'LinkAction/GetItemsbyStrategy/' + id);
            },
            GetItems: function () {
                return $http.get(baseUrl + 'LinkAction/GetItems/');
            },
            RemoveByActionType: function (params) {
                return $http.post(baseUrl + 'LinkAction/RemoveByActionType', params);
            },
            GetItemsByStrategyState: function (params) {
                return $http.post(baseUrl + 'LinkAction/GetItemsByStrategyState', params);
            },
            GetItemsByStrategyStateNoUser: function (params) {
                return $http.post(baseUrl + 'LinkAction/GetItemsByStrategyStateNoUser', params);
            }
        }
        this.stages = {
            getStagesTree: function (workflowId) {
                return $http.get(baseUrl + 'stages/getstages/' + workflowId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'stages/save', params);
            },
            update: function (params) {
                return $http.post(baseUrl + 'stages/updatestage', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'stages/remove', params);
            },
            getNodeItems: function (params) {
                return $http.post(baseUrl + 'stages/nodedata', params);
            },
            getStagesActionTree: function (workflowId) {
                return $http.get(baseUrl + 'stages/getstagesaction/' + workflowId);
            },
            getStagesEventTree: function (workflowId) {
                return $http.get(baseUrl + 'stages/getstagesevent/' + workflowId);
            },
            getStagesAlarmTree: function (workflowId) {
                return $http.get(baseUrl + 'stages/getstagesalarm/' + workflowId);
            },
            getNodeChildren: function (params) {
                return $http.post(baseUrl + 'stages/getnodechildren', params);
            },
            getChildren: function (params) {
                return $http.post(baseUrl + 'stages/getchildren', params);
            },
            saveFirtStage: function (params) {
                return $http.post(baseUrl + 'stages/savefirststage', params);
            },
            erase: function (params) {
                return $http.post(baseUrl + 'stages/erase', params);
            },
            eraseDefault: function (params) {
                return $http.post(baseUrl + 'stages/erasedefault', params);
            },
            getItemByCode: function (code) {
                return $http.post(baseUrl + 'stages/getitembycode', { Code: code });
            },
            getStagesByWorkflow: function (Id) {
                return $http.get(baseUrl + 'stages/getstagesbyworkflow/' + Id);
            },
            getStagesByWorkflowPerStrategy: function (Id) {
                return $http.get(baseUrl + 'stages/getStagesByWorkflowPerStrategy/' + Id);
            },
            /**
             * Retorna los datos de un escenario por su id.
             * @param {number} stageId Id del escenario.
             */
            getItem: function (stageId) {
                return $http.get(baseUrl + 'stages/getitem/' + stageId);
            }
        }

        this.scopeAsingments = {
            get: function (stageId) {
                return $http.get(baseUrl + 'scopeasignments/getitems/' + stageId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'scopeasignments/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'scopeasignments/remove', params);
            },
            listByWorkflows: function (stageId) {
                return $http.get(baseUrl + 'scopeasignments/GetItemsByWorkflow/' + stageId);
            },
            savescopeasignments: function (params) {
                return $http.post(baseUrl + 'scopeasignments/SaveScopeAsignments', params);
            }
        }

        this.allocationMethodAsignment = {
            get: function (stageId) {
                return $http.get(baseUrl + 'allocationmethodasignment/getitems/' + stageId);
            },
            getItemsByWorkflow: function (Id) {
                return $http.get(baseUrl + 'allocationmethodasignment/getitemsbyworkflow/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'allocationmethodasignment/save', params);
            },
            ChangeState: function (Id) {
                return $http.get(baseUrl + 'allocationmethodasignment/ChangeState/' + Id);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'allocationmethodasignment/remove', params);
            }
            ,
            ListDetail: function (params) {
                return $http.post(baseUrl + 'allocationmethodasignment/listallocationasingmethoddetail', params);
            }
            ,
            listAssignment: function (params) {
                return $http.post(baseUrl + 'allocationmethodasignment/listallocationassignmentmethod', params);
            }
        }

        this.allocationTypeAssignment = {
            getItemsByWorkflow: function (params) {
                return $http.get(baseUrl + 'allocationtypeassignment/getitemsbyworkflow/' + params);
            }
            , getItemsByWorkflowAssignment: function (params) {
                return $http.get(baseUrl + 'allocationtypeassignment/getitemsbyworkflowassignment/' + params);
            }
            , listAllocationDetail: function (params) {
                return $http.post(baseUrl + 'allocationtypeassignment/listallocationdetail', params);
            }
            , saveAssignments: function (params) {
                return $http.post(baseUrl + 'allocationtypeassignment/saveassignments', params);
            },
            getWorkflowItems: function (workflowId) {
                return $http.get(baseUrl + 'allocationtypeassignment/getworkflowitems/' + workflowId);
            }
        }
        this.allocationTypesForAlarms = {
            getPrivileges: function (params) {
                return $http.get(baseUrl + 'allocationtypesforalarms/getprivileges/' + params);
            }
            , availablePrivileges: function (params) {
                return $http.post(baseUrl + 'allocationtypesforalarms/availableprivileges', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'allocationtypesforalarms/assign', params);
            }
        }
        this.allocationTypesForActions = {
            getPrivileges: function (params) {
                return $http.get(baseUrl + 'allocationtypesforactions/getprivileges/' + params);
            }
            , availablePrivileges: function (params) {
                return $http.post(baseUrl + 'allocationtypesforactions/availableprivileges', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'allocationtypesforactions/assign', params);
            },
            /**
             * Devuelve los tipos de asignaciones de la campaña.
             * @param {number} manualCampaigId Id de campaña manual.
             */
            getAllocationTypesForCampaign: function (manualCampaignId) {
                return $http.get(baseUrl +
                    'allocationtypesforactions/getallocationtypesforcampaign' +
                    '?manualCampaignId=' + (!!manualCampaignId ? manualCampaignId : -1));
            },
            /**
             * Actualiza la relación de los tipos de asignación con la campaña manual.
             * @param {number} manualCampaignId Id de campaña manual.
             * @param {string} allocationTypesCodes Códigos de tipo de asignación.
             */
            saveAllocationsTypesForCampaign: function (manualCampaignId, allocationTypesCodes) {
                var url = baseUrl +
                    'allocationtypesforactions/saveallocationstypesforcampaign' +
                    '?manualCampaignId=' + (!!manualCampaignId ? manualCampaignId : -1);
                return $http.post(url, allocationTypesCodes);
            },
            /**
             * Devuelve todos los tipos de asignación disponibles para asociarlos a la campaña,
             * sin considerar los ya asociados.
             * @param {number} manualCampaignId Id de campaña manual.
             */
            getAllAvailableAllocationTypesForCampaign: function (manualCampaignId) {
                return $http.get(baseUrl +
                    'allocationtypesforactions/getallavailableallocationtypesforcampaign' +
                    '?manualCampaignId=' + (!!manualCampaignId ? manualCampaignId : -1));
            }
        }
        this.allocationTypesForEvents = {
            getPrivileges: function (params) {
                return $http.get(baseUrl + 'allocationtypesforevents/getprivileges/' + params);
            }
            , availablePrivileges: function (params) {
                return $http.post(baseUrl + 'allocationtypesforevents/availableprivileges', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'allocationtypesforevents/assign', params);
            }
        }
        this.allocationTypesForTypeActions = {
            getPrivileges: function (params) {
                return $http.get(baseUrl + 'AllocationTypesForTypeActions/getprivileges/' + params);
            }
            , availablePrivileges: function (params) {
                return $http.post(baseUrl + 'AllocationTypesForTypeActions/availableprivileges', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'AllocationTypesForTypeActions/assign', params);
            }
        }
        this.allocationTypesForAsignation = {
            getPrivileges: function (params) {
                return $http.post(baseUrl + 'AllocationTypesForAsignation/privileges/', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'AllocationTypesForAsignation/assign', params);
            }
            , getPercentages: function (params) {
                return $http.get(baseUrl + 'AllocationTypesForAsignation/getpercentages/' + params);
            }
            , savePercentages: function (params) {
                return $http.post(baseUrl + 'AllocationTypesForAsignation/savepercentages', params);
            }
        }

        this.allocationMethod = {
            getItems: function () {
                return $http.get(baseUrl + 'allocationmethod/getitems/');
            },
            get: function (stageId) {
                return $http.get(baseUrl + 'allocationmethod/getitems/' + stageId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'allocationmethod/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'allocationmethod/remove', params);
            }
        }

        this.allocationTypesForTransManual = {
            getPrivileges: function (params) {
                return $http.get(baseUrl + 'allocationtypesfortransmanual/getprivileges/' + params);
            }
            , availablePrivileges: function (params) {
                return $http.post(baseUrl + 'allocationtypesfortransmanual/availableprivileges', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'allocationtypesfortransmanual/assign', params);
            }
        }


        this.user = {
            //getUsers: function (lastPageIndex, pageSize) {
            //    return $http.post(baseUrl + 'user/retrieveusers', {
            //        LastPageIndex: lastPageIndex, PageSize: pageSize
            //    });
            //},
            getUsers: function (params) {
                return $http.post(baseUrl + 'user/retrieveusers', params);
            },
            getUsersScope: function (lastPageIndex, pageSize) {
                return $http.post(baseUrl + 'user/retrieveusersscope', {
                    LastPageIndex: lastPageIndex, PageSize: pageSize
                });
            },
            getUser: function (Id) {
                return $http.get(baseUrl + 'user/get/' + Id);
            },
            getUserProfile: function (Id) {
                return $http.get(baseUrl + 'user/getuserprofile/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'user/save', params);
            },
            saveEdit: function (params) {
                return $http.post(baseUrl + 'user/saveedit', params);
            },
            changePassword: function (user) {
                return $http.post(baseUrl + 'user/changePassword', user);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'user/remove', params);
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'user/getdependencies/');
            },
            getUserStates: function () {
                return $http.get(baseUrl + 'user/getuserstates/');
            },
            changePhoto: function (user) {
                return $http.post(baseUrl + 'user/changePhoto', user);
            },
            getTaskList: function (userId) {
                return $http.get(baseUrl + 'management/gettasklist/' + userId);
            },
            getAccountsData: function (id) {
                return $http.get(baseUrl + 'management/getAccountsData/' + id);
            },
            getJoinsTeams: function (userId) {
                return $http.get(baseUrl + 'user/getjointeams/' + userId);
            },
            changeScope: function (user) {
                return $http.post(baseUrl + 'user/changeScope', user);
            },
            search: function (param) {
                return $http.post(baseUrl + 'user/search', param);
            },
            setChatEnabled: function (params) {
                return $http.post(baseUrl + 'user/setchatenabled', params);
            },
            getChatEnabled: function (userId) {
                return $http.get(baseUrl + 'user/getchatenabled/' + userId);
            },
            changeOwnPassword: function (user) {
                return $http.post(baseUrl + 'user/changeownpassword', user);
            }
        }

        this.userscope = {
            get: function (params) {
                return $http.get(baseUrl + 'userscope/getitem', params);
            }
            , getItems: function () {
                return $http.get(baseUrl + 'userscope/getitems/');
            }
            , save: function (params) {
                return $http.post(baseUrl + 'userscope/save', params);
            }
            , saveScopeMembers: function (params) {
                return $http.post(baseUrl + 'userscope/saveScopeMembers', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'userscope/remove', params);
            }
            , getitemsbyscope: function (code) {
                return $http.get(baseUrl + 'userscope/getitemsbyscope/' + code);
            }
            , getasignedytems: function () {
                return $http.get(baseUrl + 'userscope/getasignedytems/');
            }
            , getavailableitems: function () {
                return $http.get(baseUrl + 'userscope/getavailableitems/');
            }
            , validarscope: function (params) {
                return $http.post(baseUrl + 'userscope/validarscope/', params);
            }
        }

        this.role = {
            getRoles: function () {
                return $http.get(baseUrl + 'role/getroles/');
            },
            getRole: function (Id) {
                return $http.get(baseUrl + 'role/get/' + Id);
            },
            getRoleFunctionsChildren: function (node) {
                return $http.post(baseUrl + 'role/getrolefunctionschildren', node);
            },
            save: function (params) {
                return $http.post(baseUrl + 'role/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'role/remove', params);
            },
            getDetails: function (Id) {
                return $http.get(baseUrl + 'role/getrolesdetails/' + Id);
            },
            /**
             * Retorna los usuarios asignados al rol.
             * @param {any} roleId Id de rol.
             * @param {any} page Nro. de p�gina.
             * @param {any} length Filas por p�gina.
             * @param {any} filter Filtro (por email, nombre o login).
             */
            getAssignedRoleUsers: function (roleId, page, length, filter) {
                return $http.get(baseUrl +
                    'role/getassignedroleusers?roleId=' + roleId +
                    '&page=' + page +
                    '&length=' + length +
                    (!!filter ? '&filter=' + filter : ''));
            },
            /**
             * Retorna los usuarios a�n no asignados al rol.
             * @param {any} roleId Id de rol.
             * @param {any} page Nro. de p�gina.
             * @param {any} length Filas por p�gina.
             * @param {any} filter Filtro (por email, nombre o login).
             */
            getAvailableRoleUsers: function (roleId, page, length, filter) {
                return $http.get(baseUrl +
                    'role/getavailableroleusers?roleId=' + roleId +
                    '&page=' + page +
                    '&length=' + length +
                    (!!filter ? '&filter=' + filter : ''));
            },
            /**
             * Asigna todos los usuarios al rol.
             * @param {number} roleId Id del rol.
             * @param {Array<number>} excludedUsersIds
             * Lista de ids de usuarios que no ser�n asignados (ser�n excluidos de la asignaci�n).
             */
            assignAllUsersToRole: function (roleId, excludedUsersIds) {
                return $http.post(baseUrl + 'role/assignalluserstorole?roleId=' + roleId, excludedUsersIds);
            },
            /**
             * Desasigna todos los usuarios del rol.
             * @param {number} roleId Id del rol.
             * @param {Array<number>} excludedUsersIds
             * Lista de ids de usuarios que no ser�n desasignados (ser�n excluidos de la desasignaci�n).
             */
            makeAvailableAllUsersToRole: function (roleId, excludedUsersIds) {
                return $http.post(baseUrl + 'role/makeavailablealluserstorole?roleId=' + roleId, excludedUsersIds);
            },
            saveUsersRole: function (params) {
                return $http.post(baseUrl + 'role/saveusersrole', params);
            },
            saveFunctionsrole: function (params) {
                return $http.post(baseUrl + 'role/savefunctionsrole', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'role/clone', params);
            }
        }

        this.functions = {
            getFunctions: function () {
                return $http.get(baseUrl + 'function/getfunctions/');
            },
            /**
             * Retorna la funci�n que corresponde al c�digo.
             * @param {string} functionCode C�digo de funci�n.
             */
            getFunctionByCode: function (functionCode) {
                return $http.get(baseUrl + 'function/getfunctionbycode' +
                    '?functionCode=' + (!!functionCode ? functionCode : ''));
            },
            /**
             * Realiza una b�squeda por las funciones que tienen URL.
             * @param {string} name Nombre de la funci�n.
             * @param {string} description Descripci�n de la funci�n.
             */
            getUrlFunctions: function (name, description) {
                return $http.get(baseUrl + 'function/geturlfunctions' +
                    '?name=' + (!!name ? name : '') +
                    '&description=' + (!!description ? description : ''));
            },
            /**
             * Retorna las funciones asociadas al par�metro. Solo toma en cuenta las que tienen un valor en el campo 'url'.
             * @param {string} parameterCode C�digo de par�metro.
             * @param {string} functionTypeCode C�digo tipo de funci�n.
             * @param {string} schema Esquema.
             */
            getUrlFunctionsByParameter: function (
                parameterCode,
                functionTypeCode,
                schema
            ) {
                return $http.get(baseUrl + 'function/geturlfunctionsbyparameter' +
                    '?parameterCode=' + (!!parameterCode ? parameterCode : '') +
                    '&functionTypeCode=' + (!!functionTypeCode ? functionTypeCode : '') +
                    '&schema=' + (!!schema ? schema : ''));
            },
            getFunction: function (Id) {
                return $http.get(baseUrl + 'function/get/' + Id)
            },
            save: function (params) {
                return $http.post(baseUrl + 'function/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'function/delete', params);
            },
            searchItemByCode: function (params) {
                return $http.post(baseUrl + 'function/searchitembycode', params);
            },
            getFunctionsBySchema: function (params) {
                return $http.post(baseUrl + 'function/getfunctionsbyschema', params);
            }
        }

        this.functionTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'FunctionTypes/getItems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'FunctionTypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'FunctionTypes/remove', params);
            }
        }

        this.layout = {
            getListLayoutByWorkflow: function (id) {
                return $http.get(baseUrl + 'layout/getlistlayoutbyworkflow/' + id)
            },
            getItemListLayoutById: function (id) {
                return $http.get(baseUrl + 'layout/getitemlistlayoutbyid/' + id)
            },
            getLayoutEditById: function (id) {
                return $http.get(baseUrl + 'layout/getlayouteditbyid/' + id);
            },
            getLayoutByObjectId: function (id) {
                return $http.get(baseUrl + 'layout/getlayoutbyobjectid/' + id);
            },
            saveLayout: function (ficha) {
                return $http.post(baseUrl + 'layout/savelayout', ficha);
            },
            saveLayoutFicha: function (ficha) {
                return $http.post(baseUrl + 'layout/savelayoutficha', ficha);
            },
            removeLayoutFicha: function (ficha) {
                return $http.post(baseUrl + 'layout/removelayoutficha', ficha);
            },
            removeLayoutFichaContent: function (content) {
                return $http.post(baseUrl + 'layout/removelayoutfichacontent', content);
            },
            removeLayout: function (param) {
                return $http.post(baseUrl + 'layout/removelayout', param);
            },
            getLayoutById: function (id) {
                return $http.get(baseUrl + 'layout/getlayoutbyid/' + id);
            },
            editOrderLayout: function (ficha) {
                return $http.post(baseUrl + 'layout/editorderlayout', ficha);
            },
            /**
             * Devuelve las secciones de un layout por su c�digo.
             * @param {string} code C�digo del layout.
             */
            getLayoutByCode: function (code) {
                return $http.get(baseUrl + 'layout/getlayoutbycode?code=' + code);
            },
            saveRow: function (row) {
                return $http.post(baseUrl + 'layout/saverow', row);
            },
            saveContent: function (content) {
                return $http.post(baseUrl + 'layout/savecontent', content);
            },
            searchLayoutByType: function (param) {
                return $http.post(baseUrl + 'layout/searchlayoutbytype', param);
            },
            getLayoutsByEntity: function (param) {
                return $http.get(baseUrl + 'layout/getlayoutsbyentity/' + param);
            },
            //
            // Cambia el t�tulo de una secci�n (o fila) de un layout de consulta.
            // @param {any} title Nuevo t�tulo de la secci�n.
            // @param {number} rowId Id de la secci�n.
            //
            changeRowTitle: function (title, rowId) {
                title = title ? title : '';
                rowId = rowId ? rowId : '';

                return $http.post(baseUrl + 'layout/changerowtitle?title=' + title + '&rowId=' + rowId);
            },
            //
            // Cambia el orden de una secci�n (o fila) de un layout de consulta.
            // @param {number} layoutId Id del layout.
            // @param {number} rowId Id de la secci�n.
            // @param {number} newOrder Nuevo orden.
            //
            changeRowOrder: function (layoutId, rowId, newOrder) {
                layoutId = layoutId ? layoutId : 0;
                rowId = rowId ? rowId : 0;
                newOrder = newOrder ? newOrder : 0;

                return $http.post(baseUrl +
                    'layout/changeroworder?layoutId=' + layoutId +
                    '&rowId=' + rowId +
                    '&newOrder=' + newOrder);
            },
            //
            // Cambia el orden de un apartado (o columna) de una secci�n, de un layout de consulta.
            // @param {number} rowId Id de la secci�n.
            // @param {number} colId Id del apartado a ordenar.
            // @param {number} newOrder Nuevo orden.
            //
            changeColOrder: function (rowId, colId, newOrder) {
                rowId = rowId ? rowId : 0;
                colId = colId ? colId : 0;
                newOrder = newOrder ? newOrder : 0;

                return $http.post(baseUrl +
                    'layout/changecolorder?rowId=' + rowId +
                    '&colId=' + colId +
                    '&newOrder=' + newOrder);
            }
        }

        this.workflows = {
            getWorkflows: function () {
                return $http.get(baseUrl + 'workflows/getworkflows/');
            },
            getWorkflowByBusinessCode: function (id) {
                return $http.get(baseUrl + 'workflows/GetWorkflowByBusinessCode/' + id);
            },
            getWorkflow: function (id) {
                return $http.get(baseUrl + 'workflows/getworkflow/' + id);
            },
            getWorkflowForUser: function (id) {
                return $http.get(baseUrl + 'workflows/getworkflowsforuser/');
            },
            getWorkflowsByUser: function () {
                return $http.get(baseUrl + 'workflows/GetWorkflowsByUser/');
            },
            getWorkflowsByType: function (id) {
                return $http.post(baseUrl + 'workflows/GetWorkflowsByType' + id);
            },
            getStatesByWorkflow: function (id) {
                return $http.get(baseUrl + 'workflows/getStatesByWorkflow/' + id);
            },
            getWorkflowFatherBy: function (param) {
                return $http.post(baseUrl + 'workflows/GetWorkflowFatherBy', param);
            },
            save: function (params) {
                return $http.post(baseUrl + 'workflows/save', params);
            },
            saveAndRetrieve: function (params) {
                return $http.post(baseUrl + 'workflows/SaveAndRetrieve', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'workflows/remove', params);
            },
            getUsers: function (id) {
                return $http.get(baseUrl + 'workflows/getusers/' + id);
            },
            "export": function (options) {
                return $http.post(baseUrl + 'wflexport/export', options);
            },
            canImport: function (workflowId) {
                return $http.post(baseUrl + 'wflimport/canimport/' + workflowId);
            },
            "import": function (options) {
                return $http.post(baseUrl + 'wflimport/import', options);
            },
            GetUserByTeamAndWfl: function (workflowId) {
                return $http.get(baseUrl + 'workflows/GetUserByTeamAndWfl/' + workflowId);
            },
            GetTeamsByWorkflow: function (workflowId) {
                return $http.get(baseUrl + 'workflows/GetTeamsByWorkflow/' + workflowId);
            },
            GetTeamsByUserAndWfl: function (workflowId) {
                return $http.get(baseUrl + 'workflows/GetTeamsByUserAndWfl/' + workflowId);
            },
            getItemByCode: function (code) {
                return $http.post(baseUrl + 'workflows/getitembycode', { Code: code });
            },
            GetWorkflowsViewByUser: function () {
                return $http.get(baseUrl + 'workflows/GetWorkflowsViewByUser/');
            },
            /**
             * Devuelve los workflows correspondientes a la persona.
             * @param {number} personId Id de la persona.
             */
            getWorkflowsByPerson: function (personId) {
                return $http.get(baseUrl + 'workflows/getworkflowsbyperson' +
                    '?personId=' + (!!personId ? personId : -1));
            },
            /**
             * Desencadena el evento 'refreshObjects', que provoca la actualizaci�n
             * de los objetos para un workflow y persona espec�fica.
             * Replica el evento en todos los clientes que est�n gestionando a esa persona.
             * @param {number} workflowId Id del workflow.
             * @param {number} personId Id de la persona.
             */
            echoRefreshObjects: function (workflowId, personId) {
                var url = 'workflows/echorefreshobjects' +
                    '?workflowId=' + (!!workflowId ? workflowId : -1) +
                    '&personId=' + (!!personId ? personId : -1);

                return $http.get(baseUrl + url);
            },
            /**
             * Desencadena el evento 'refreshObjects', que provoca la actualizaci�n
             * de los objetos para un workflow y persona espec�fica.
             * Replica el evento en todos los clientes que est�n gestionando a esa persona.
             * @param {number} workflowTypeCode Id del workflow.
             * @param {number} personId Id de la persona.
             */
            echoRefreshObjectsByWorkflowType: function (workflowTypeCode, personId) {
                var url = 'workflows/echorefreshobjects' +
                    '?workflowTypeCode=' + (!!workflowTypeCode ? workflowTypeCode : -1) +
                    '&personId=' + (!!personId ? personId : -1);

                return $http.get(baseUrl + url);
            },
            /**
             * Desencadena el evento 'refreshClientManagementWorkflows',
             * que provoca la actualizaci�n de las managemntTabs de la ficha de la persona.
             * Replica el evento en todos los clientes que est�n gestionando a esa persona.
             * @param {number} personId Id de persona.
             */
            echoRefreshClientManagementWorkflows: function (personId) {
                var url = 'workflows/echorefreshclientmanagementworkflows' +
                    '?personId=' + (!!personId ? personId : -1);

                return $http.get(baseUrl + url);
            }
        }

        this.metadata = {
            getActions: function () {
                return $http.get(baseUrl + 'metactions/get');
            },
            getAction: function (code) {
                return $http.get(baseUrl + 'metactions/getitem/' + code);
            },
            getModels: function () {
                return $http.get(baseUrl + 'models/getmodels');
            },
            saveModel: function (model) {
                return $http.post(baseUrl + 'models/save', model);
            },
            getEntitiesTree: function () {
                return $http.get(baseUrl + 'entities/getentitiestree');
            },
            getEntity: function (entityCode) {
                return $http.get(baseUrl + 'entities/getentity/' + entityCode);
            },
            getEntitiesModel: function (modelCode) {
                return $http.get(baseUrl + 'entities/getentitiesmodel/' + modelCode);
            },
            getEntitiesDependencies: function () {
                return $http.get(baseUrl + 'entities/getdependencies');
            },
            getAttributeByTypes: function (param) {
                return $http.post(baseUrl + 'attributes/getAttributeByTypes', { Code: param });
            },
            searchAttributes: function (filter) {
                return $http.post(baseUrl + 'attributes/searchAttributes', { Code: filter });
            },
            getAttributes: function (entity) {
                if (entity) {
                    return $http.get(baseUrl + 'attributes/getattributes/' + entity);
                }
                else {
                    return $http.get(baseUrl + 'attributes/get');
                }
            },
            getListAttributes: function (filter) {
                return $http.get(baseUrl + 'attributes/getlistattributes/' + filter);
            },//logico
            removeAttribute: function (params) {
                return $http.post(baseUrl + 'attributes/remove', params);
            },//fisico
            deleteAttribute: function (params) {
                return $http.post(baseUrl + 'attributes/delete', params);
            },
            syncAttributes: function (params) {
                return $http.post(baseUrl + 'attributes/sync', params);
            },
            getAttributeTypes: function () {
                return $http.get(baseUrl + 'attributes/getattributestypes');
            },
            saveAttributes: function (params) {
                return $http.post(baseUrl + 'attributes/save', params);
            },
            getAllAttributes: function (param) {
                return $http.get(baseUrl + 'attributes/getallitems/' + param);
            },
            getAllAttributesWithMarks: function (param) {
                return $http.get(baseUrl + 'attributes/getallitemsWithMarks/' + param);
            },
            getallitemsWithMarksByWfl: function (param) {
                return $http.post(baseUrl + 'attributes/getallitemswithmarksbywfl', param);
            },
            getAllGroups: function () {
                return $http.get(baseUrl + 'attributes/GetAllGroups');
            },
            getFunctionsTree: function () {
                return $http.get(baseUrl + 'function/getfunctionstree');
            },
            getFunctionsTreeByType: function (filter) {
                return $http.post(baseUrl + 'function/getfunctionstreebytype', filter);
            },
            getMenusTree: function () {
                return $http.get(baseUrl + 'menus/getmenustree');
            },
            getEvents: function () {
                return $http.get(baseUrl + 'metevent/getmetadataevents');
            },
            getScopes: function () {
                return $http.get(baseUrl + 'scopes/GetItems');
            },
            saveScopes: function (params) {
                return $http.post(baseUrl + 'scopes/save', params);
            },
            getComponents: function () {
                return $http.get(baseUrl + 'components/GetItems');
            },
            saveComponents: function (params) {
                return $http.post(baseUrl + 'components/save', params);
            },
            getAttributeEntityRecords: function (params) {
                return $http.post(baseUrl + 'attributes/attributefields', params);
            },
            attributefieldsbyqrydto: function (params) {
                return $http.post(baseUrl + 'attributes/attributefieldsbyqrydto', params);
            },
            getEntitiesNodes: function (filter) {
                return $http.post(baseUrl + 'entities/getnodes', filter);
            },
            saveEntity: function (entity) {
                return $http.post(baseUrl + 'entities/save', entity);
            },//logico
            removeEntity: function (entity) {
                return $http.post(baseUrl + 'entities/remove', entity);
            },//fisico
            deleteEntity: function (entity) {
                return $http.post(baseUrl + 'entities/delete', entity);
            },
            getEntityNode: function (entityCode) {
                return $http.get(baseUrl + 'entities/getentitynode/' + entityCode);
            },
            getEntityWithBrandsActive: function () {
                return $http.get(baseUrl + 'entities/GetEntityWithBrandsActive');
            },
            listEntitiesNodes: function (filter) {
                return $http.post(baseUrl + 'entities/listnodes', filter);
            },
            getViewEntities: function (entityCode) {
                return $http.get(baseUrl + 'entities/getviewentities/');
            },
            searchViewEntity: function (filter) {
                return $http.post(baseUrl + 'entities/searchviewentity', filter);
            },
            saveEntityComplete: function (item) {
                return $http.post(baseUrl + 'entities/SaveEntityComplete', item);
            },
            /**
             * Ordena el atributo pertneciente a la entidad.
             * @param {string} entityCode C�digo de entidad que contiene al atributo a ordenar.
             * @param {string} attributeCode C�digo del atributo a ordenar.
             * @param {number} newOrder Nuevo orden del atributo.
             */
            changeAttributesOrder: function (entityCode, attributeCode, newOrder) {
                return $http.post(baseUrl + 'attributes/changeorder' +
                    '?entityCode=' + (!!entityCode ? entityCode : '') +
                    '&attributeCode=' + (!!attributeCode ? attributeCode : '') +
                    '&newOrder=' + (!!newOrder ? newOrder : 0)
                );
            },
            getOperators: function () {
                return $http.get(baseUrl + 'operators/getoperators');
            },
            getOperatorsByDataType: function (dataType) {
                return $http.get(baseUrl + 'operators/getoperatorsbydatatype/' + dataType);
            },
            getItemsByWorkflow: function (param) {
                return $http.get(baseUrl + 'attributes/getitemsbyworkflow/' + param);
            },
            getBatchStates: function () {
                return $http.get(baseUrl + 'batchstate/getitems')
            },
            getParameterTypes: function () {
                return $http.get(baseUrl + 'parameterTypes/getitems')
            },
            getManagementStatus: function () {
                return $http.get(baseUrl + 'managementstatus/getitems')
            },
            getModelDocumentTypes: function () {
                return $http.get(baseUrl + 'modeldocument/getitems');
            },
            getCampaingStatus: function () {
                return $http.get(baseUrl + 'MetCampaingState/get')
            },
            getAutoCampaingStatus: function () {
                return $http.get(baseUrl + 'MetAutoCampaignState/get')
            },
            getLayoutTypes: function () {
                return $http.get(baseUrl + 'layouttypes/getitems');
            },
            saveLayoutType: function (params) {
                return $http.post(baseUrl + 'layouttypes/save', params);
            },
            getTaskTypes: function () {
                return $http.get(baseUrl + 'TaskTypes/getitems');
            },
            saveTaskType: function (params) {
                return $http.post(baseUrl + 'TaskTypes/save', params);
            },
            getOnlineProcessTypes: function () {
                return $http.get(baseUrl + 'MetOnlineProcesses/getitems');
            },
            saveOnlineProcessType: function (params) {
                return $http.post(baseUrl + 'MetOnlineProcesses/save', params);
            },
            getAuthenticationMethods: function () {
                return $http.get(baseUrl + 'AuthenticationMethod/getitems');
            },
            saveAuthenticationMethod: function (params) {
                return $http.post(baseUrl + 'AuthenticationMethod/save', params);
            },
            getViewTypes: function () {
                return $http.get(baseUrl + 'MetViewType/getitems');
            },
            saveViewType: function (params) {
                return $http.post(baseUrl + 'MetViewType/save', params);
            },
            saveModelDocumentTypes: function (params) {
                return $http.post(baseUrl + 'modeldocument/save', params);
            }
        }

        this.entities = {
            getEntities: function () {
                return $http.get(baseUrl + 'entities/getentities/');
            },
            /**
             * Retorna las entidades param�tricas.
             * */
            getParametricEntities: function () {
                return $http.get(baseUrl + 'entities/getparametricentities/');
            },
            getEntitiesTabView: function () {
                return $http.get(baseUrl + 'entities/getEntitiesTabView/');
            },
            /* 20200306: Eliminar este */
            getTransactionalEntities: function () {
                return $http.get(baseUrl + 'entities/gettransactionalentities');
            },
            /**
             * Retorna las entidades disponibles para utilizar en las consultas de usuario.
             * */
            getUsersQueryEntities: function () {
                return $http.get(baseUrl + 'entities/getusersqueryentities');
            },
            /**
             * Retorna las entidades disponibles para utilizar en las consultas de sistema.
             * */
            getCoreQueryEntities: function () {
                return $http.get(baseUrl + 'entities/getcorequeryentities');
            },
            getTransactionalTableEntities: function () {
                return $http.get(baseUrl + 'entities/getTransactionalTableEntities');
            },
            getRelationalEntitiesOf: function (id) {
                return $http.get(baseUrl + 'entities/getrelationalentitiesof/' + id);
            }
        };

        this.examples = {
            getTreeData: function (code) {
                return $http.post(baseUrl + 'treeexamples/treedata', { Code: code });
            },
            getMetadataTreeData: function () {
                return $http.get(baseUrl + 'treeexamples/getmetadatatreedata');
            },
            saveTree: function (params) {
                return $http.post(baseUrl + 'treeexamples/save', params);
            },
            removeTree: function (params) {
                return $http.post(baseUrl + 'treeexamples/remove', params);
            },
            getAttribute: function (params) {
                return $http.post(baseUrl + 'treeexamples/entityattibutedetailtreedata', params);
            },
            getTranItems: function (Id) {
                return $http.get(baseUrl + 'listexample/getitems/');
            }
        }

        this.crudExample = {
            get: function (params) {
                return $http.get(baseUrl + 'parametricexample/getitem', params);
            }
            , getItems: function () {
                return $http.get(baseUrl + 'parametricexample/getitems/');
            }
            , save: function (params) {
                return $http.post(baseUrl + 'parametricexample/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'parametricexample/remove', params);
            }
        }

        this.parametricEntity = {
            getItems: function (params) {
                return $http.get(baseUrl + 'parametricentity/getitems', params);
            }
        }

        this.manageTeams = {
            getItems: function () {
                return $http.get(baseUrl + 'managementteam/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'managementteam/getitem/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'managementteam/save', params);
            },
            getTeamMembers: function (Id) {
                return $http.get(baseUrl + 'teammembers/getteammembers/' + Id);
            },
            saveTeamMembers: function (params) {
                return $http.post(baseUrl + 'managementteammembers/saveteammembers', params);
            },
            getMyTeams: function () {
                return $http.get(baseUrl + 'managementteam/getmyteams');
            }
        }

        this.queries = {
            getAccounts: function (id, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/runbyid', { Id: id });
            },
            get: function () {
                return $http.get(baseUrl + 'queries/get/');
            },
            GetByParamCode: function (param) {
                return $http.get(baseUrl + 'queries/GetByParamCode/' + param);
            },
            resolve: function (query, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/resolve', query);
            },
            resolveById: function (id, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/resolvebyid', { Id: id });
            },
            run: function (query, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/run', { Code: code });
            },
            runById: function (id, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/runbyid', { Id: id });
            },
            runPage: function (query, schema, uId, pageNumber, pageSize) {
                $http.defaults.headers.common.qpschema = schema;

                var params = {
                    query: query,
                    uId: uId,
                    pageSize: pageSize,
                    pageNumber: pageNumber,
                };

                return $http.post(baseUrl + 'queries/runPage', params);
            },
            runPageSorted: function (query, schema, uId, pageNumber, pageSize, columnSort) {
                $http.defaults.headers.common.qpschema = schema;

                var params = {
                    query: query,
                    uId: uId,
                    pageSize: pageSize,
                    pageNumber: pageNumber,
                    columnSort: columnSort,
                };

                return $http.post(baseUrl + 'queries/runPageSorted', params);
            }
            , save: function (params) {
                return $http.post(baseUrl + 'queries/save', params);
            }
            , saveAll: function (params) {
                return $http.post(baseUrl + 'queries/saveall', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'queries/remove', params);
            }
            , removeById: function (id) {
                return $http.post(baseUrl + 'queries/removebyid', { Id: id });
            }
            , getscript: function (params) {
                return $http.post(baseUrl + 'queries/resolvescript', { Code: code });
            }
            , getQuerys: function () {
                return $http.get(baseUrl + 'queries/getquerys/');
            }
            , saveQuery: function (params) {
                return $http.post(baseUrl + 'queries/savequery', params);
            }
            , saveQueryAction: function (params) {
                return $http.post(baseUrl + 'queries/savequeryaction', params);
            }
            , saveQueryActionParam: function (params) {
                return $http.post(baseUrl + 'queries/savequeryactionParams', params);
            }
            , GetQueryActionParams: function (params) {
                return $http.post(baseUrl + 'queries/GetQueryActionParams', params);
            }
            , GetActionInfo: function (params) {
                return $http.post(baseUrl + 'queries/GetActionInfo', params);
            }
            , removeQueryAction: function (params) {
                return $http.post(baseUrl + 'queries/removequeryaction', params);
            }
            , saveQueryBreak: function (params) {
                return $http.post(baseUrl + 'queries/savequerybreak', params);
            }
            , removeQueryBreak: function (params) {
                return $http.post(baseUrl + 'queries/removequerybreak', params);
            }
            , resolveDetail: function (params) {
                return $http.post(baseUrl + 'queries/resolvedetail', { Code: params });
            }
            , saveQueryClone: function (params) {
                return $http.post(baseUrl + 'queries/savequeryclone', params);
            }
            , saveQueryUser: function (params) {
                return $http.post(baseUrl + 'queries/updatequeriesuser', params);
            }
            , RunByCode: function (params, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/runbycode', params);
            }
            , ResolveByIdWithoutQuery: function (params, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/resolvebyidwithoutquery', { Id: id });
            }
            , ResolveWithoutQuery: function (params, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'queries/resolvewithoutquery', params);
            }
            , getItem: function (id) {
                return $http.get(baseUrl + 'queries/GetItem/' + id);
            }
            , checkScopePivot: function (id) {
                return $http.get(baseUrl + 'queries/checkScopePivot/' + id);
            }
        }

        this.querycols = {
            getItem: function (Id) {
                return $http.get(baseUrl + 'querycols/GetItem/' + Id);
            },
            getItemsByQuery: function (Id) {
                return $http.get(baseUrl + 'querycols/GetItemsByQuery/' + Id);
            },
            getItemsByName: function (params) {
                return $http.post(baseUrl + 'querycols/getitemsbyname', { Code: params });
            },
            getAttributeItems: function (attributeCode) {
                return $http.post(baseUrl + 'querycols/attributecolumns', { Code: attributeCode });
            },
            save: function (params) {
                return $http.post(baseUrl + 'querycols/save', params);
            },
            saveAll: function (params) {
                return $http.post(baseUrl + 'querycols/saveall', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'querycols/remove', params);
            },
            saveFunction: function (params) {
                return $http.post(baseUrl + 'querycols/savefunction', params);
            },
            removeFunction: function (params) {
                return $http.post(baseUrl + 'querycols/removefunction', params);
            }
        }
        this.queryfilter = {
            getItems: function (queryId) {
                return $http.get(baseUrl + 'queryfilter/getitems/' + queryId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'queryfilter/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'queryfilter/remove', params);
            },
            saveFilter: function (params) {
                return $http.post(baseUrl + 'queryfilter/savefilter', params);
            },
            saveFilterQuery: function (params) {
                return $http.post(baseUrl + 'queryfilter/savefilterquery', params);
            },
            getItemsByIds: function (params) {          // 20160921
                return $http.post(baseUrl + 'queryfilter/getitemsbylistofids', params);
            },
            pasteFilters: function (params) {
                return $http.post(baseUrl + 'queryfilter/copy', params);
            },
            saveFilterQueryEntity: function (params) {
                return $http.post(baseUrl + 'queryfilter/SaveFilterQueryEntity', params);
            },
        }
        this.queryorder = {
            save: function (params) {
                return $http.post(baseUrl + 'queryorder/save', params);
            },
            erase: function (params) {
                return $http.post(baseUrl + 'queryorder/erase', params);
            }
        }

        this.queryPrivileges = {
            //getPrivileges: function (qryId) {
            //    return $http.get(baseUrl + 'queryonlprivileges/getprivileges/' + qryId);
            //},
            //getAvailablePrivileges: function (qryId) {
            //    return $http.get(baseUrl + 'queryonlprivileges/getavailableprivileges/' + qryId);
            //},
            //assign: function (item) {
            //    return $http.post(baseUrl + 'queryonlprivileges/assign', item);
            //},
            //unassign: function (item) {
            //    return $http.post(baseUrl + 'queryonlprivileges/unassign', item);
            //},
            getPrivileges: function (params) {
                return $http.get(baseUrl + 'queryonlprivileges/getprivileges/' + params);
            }
            , availablePrivileges: function (params) {
                return $http.post(baseUrl + 'queryonlprivileges/availableprivileges', params);
            }
            , assign: function (params) {
                return $http.post(baseUrl + 'queryonlprivileges/assign', params);
            }
        }

        this.queryNodes = {
            getNodes: function (filter) {
                return $http.post(baseUrl + 'querynodes/getnodes', filter);
            },
            save: function (node) {
                return $http.post(baseUrl + 'querynodes/save', node);
            },
            remove: function (node) {
                return $http.post(baseUrl + 'querynodes/remove', node);
            }
        }

        this.queryOnl = {
            getItem: function (id) {
                return $http.get(baseUrl + 'queryonl/GetItem/' + id);
            },
            /* 202003 QUITAR */
            getItemsByCode: function (code) {
                return $http.get(baseUrl + 'queryonl/getitemsbycode/' + code);
            },
            /**
             * Devuelve las consultas de usuario.
             * */
            getUserQueries: function () {
                return $http.get(baseUrl + 'queryonl/getuserqueries');
            },
            /**
             * Devuelve las consultas de sistema.
             * */
            getCoreQueries: function () {
                return $http.get(baseUrl + 'queryonl/getcorequeries');
            },
            /**
             * Devuelve las consultas de gu�a.
             * */
            getGuideQueries: function () {
                return $http.get(baseUrl + 'queryonl/getguidequeries');
            },
            getItemsWithSecurity: function (code) {
                return $http.get(baseUrl + 'queryonl/getitemswithsecurity/' + code);
            },
            getGroups: function (code) {
                return $http.get(baseUrl + 'queryonl/getgroups/' + code);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'queryonl/remove', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'queryonl/save', params);
            },
            getItemByCompanyTypeCode: function (params) {
                return $http.post(baseUrl + 'queryonl/itembycompanytypecode', params);
            },
            GetAttributesFromQuery: function (id) {
                return $http.get(baseUrl + 'queryonl/GetAttributesFromQuery/' + id);
            }
        }

        this.batch = {
            runExecution: function (params) {
                $http.defaults.headers.common.showloader = false;
                return $http.post(baseUrl + 'ssis/runexecution', params);
            }
            , runExecutionAsync: function (params) {
                return $http.post(baseUrl + 'ssis/runexecutionasync', params);
            }
            , getJobs: function () {
                return $http.get(baseUrl + 'ssis/getjobs');
            }
            , runJobs: function (params) {
                $http.defaults.headers.common.showloader = false;
                return $http.post(baseUrl + 'ssis/runjobs', params);
            }
            , getProcess: function (params) {
                return $http.post(baseUrl + 'ssis/readprocess', { Code: params });
            }
            , runProcess: function (params) {
                $http.defaults.headers.common.showloader = false;
                return $http.post(baseUrl + 'ssis/runprocess', params);
            }
            , getExecution: function (params) {
                return $http.get(baseUrl + 'ssis/getexecution/' + params);
            }
        }

        this.batchProcess = {
            getItems: function () {
                return $http.get(baseUrl + 'batchprocess/getitems/');
            },
            getTree: function () {
                return $http.get(baseUrl + 'batchprocess/getTree/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'batchprocess/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'batchprocess/remove', params);
            },
            delete: function (id) {
                return $http.post(baseUrl + 'batchprocess/delete/' + id);
            }
        }

        this.batchLogs = {
            getJobsExecutionLogs: function (filter) {
                return $http.post(baseUrl + 'batchlogs/getjobexecutionlogs', filter);
            },
            getProcessesExecutionLogs: function (filter) {
                return $http.post(baseUrl + 'batchlogs/getprocessexecutionlogs', filter);
            },
            getExecutionsLogs: function (filter) {
                return $http.post(baseUrl + 'batchlogs/getexecutionlogs', filter);
            }
        }

        this.processTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'processtypes/getitems/');
            }
        }

        this.processJob = {
            getAllItemsByJob: function (id) {
                return $http.get(baseUrl + 'processjob/GetAllItemsByJob/' + id);
            },
            saveProcessesByJob: function (params) {
                return $http.post(baseUrl + 'processjob/SaveProcessMembers', params);
            }
        }

        this.ssis = {
            getLogJobExecution: function (params) {
                return $http.get(baseUrl + 'ssis/getlogjobexecution/' + params);
            },
            getLogDetail: function (params) {
                return $http.get(baseUrl + 'ssis/getlogdetail/' + params);
            },
            getlogfunctional: function (params) {
                return $http.get(baseUrl + 'ssis/getlogfunctional/' + params);
            },
            getParams: function () {
                return $http.get(baseUrl + 'ssis/getparameters');
            },
            getSchedule: function (params) {
                return $http.get(baseUrl + 'schedule/getitem/' + params);
            },
            getSchedules: function (params) {
                return $http.get(baseUrl + 'schedule/getitems');
            },
            saveSchedule: function (params) {
                return $http.post(baseUrl + 'schedule/save', params);
            },
            removeSchedule: function (params) {
                return $http.post(baseUrl + 'schedule/remove', params);
            },
            getFixedMoment: function () {
                return $http.get(baseUrl + 'schedule/getfixedmoment');
            },
            getFixedWeekday: function () {
                return $http.get(baseUrl + 'schedule/getfixedweekday');
            }
        }

        this.batchSchedule = {
            getTypes: function () {
                return $http.get(baseUrl + 'scheduletypes/getitems');
            }
            //no tiene su metodo en controller
            //,getType: function (code) {
            //    return $http.get(baseUrl + 'scheduletypes/getitem', { Code: code });
            //}
        }

        this.jobs = {
            getItems: function () {
                return $http.get(baseUrl + 'jobs/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'jobs/getitem/' + id);
            },
            getByScheduleType: function (id) {
                return $http.get(baseUrl + 'jobs/getByScheduleType?schedule=' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'jobs/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'jobs/remove', params);
            }
        };


        this.interface = {
            getItems: function () {
                return $http.get(baseUrl + 'interface/getitems');
            }
            , getItemsOnl: function () {
                return $http.get(baseUrl + 'interface/getitemsonl');
            }
            , save: function (params) {
                return $http.post(baseUrl + 'interface/save', params);
            }
            , saveInterfaceAttach: function (params) {
                return $http.post(baseUrl + 'interface/saveinterfaceattach', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'interface/remove', params);
            }
            , getDetail: function () {
                return $http.get(baseUrl + 'interface/getinterfacedetail');
            }
            , getType: function () {
                return $http.get(baseUrl + 'interface/getinterfacetypes');
            }
            , saveType: function (params) {
                return $http.post(baseUrl + 'interface/saveinterfacetype', params);
            }
            , removeType: function (params) {
                return $http.post(baseUrl + 'interface/removeinterfacetype', params);
            }
            , getFilesByInterface: function (Id) {
                return $http.get(baseUrl + 'interface/getfilesbyinterface/' + Id);
            }
            , getConfiguration: function (params) {
                return $http.post(baseUrl + 'interface/getconfiguration', params);
            }
            , getFileDetail: function (params) {
                return $http.post(baseUrl + 'interface/retrievefiledetail/', params);
            }
            , process: function (id) {
                return $http.get(baseUrl + 'interface/process/' + id);
            }
            , validate: function (id) {
                return $http.get(baseUrl + 'interface/validate/' + id);
            }
            , download: function (id) {
                return $http.get(baseUrl + 'interface/download/' + id, { responseType: 'blob' });
            }
        }

        this.parameterConversion = {
            getItems: function (schema, company, entity) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.get(baseUrl + 'parameterconversion/getitems?Company=' + company + '&Entity=' + entity);
            },
            saveItems: function (items, schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'parameterconversion/saveitems', items);
            },
            getEntities: function (schema, table) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.get(baseUrl + 'parameterconversion/getEntities?Table=' + table);
            },
            copyDefaults: function (schema, company, entity, table) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.post(baseUrl + 'parameterconversion/copyDefaults', { Schema: schema, Company: company, Entity: entity, Table: table });
            }
        }
        this.upload =
        {
            getUrl: function () { return baseUrl + 'upload/postformdata'; }
        }

        this.extensions = {
            get: function (placeholder) {
                return $http.get(baseUrl + 'extensions/get/' + placeholder);
            },
            getItems: function () {
                return $http.get(baseUrl + 'extensions/getitems/');
            },
            getById: function (params) {
                return $http.post(baseUrl + 'extensions/extensionbyid', { Id: params });
            },
            getItemsByType: function (type) {
                return $http.post(baseUrl + 'extensions/getitemsbytype', { Code: type });
            },
            GetByCode: function (code) {
                return $http.post(baseUrl + 'extensions/GetByCode', { Code: code });
            }
        }

        this.workflowStates = {
            getItems: function () {
                return $http.get(baseUrl + 'workflowstates/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'workflowstates/getitem/' + id);
            },
            getWorkflowTypeItems: function (workflowTypeCode) {
                return $http.post(baseUrl + 'workflowstates/workflowTypeItems', { Code: workflowTypeCode });
            },
            getWorkflowStatesByWorkflowAndStrategy: function (params) {
                return $http.post(baseUrl + 'workflowstates/getStatesByWorkflowAndStrategy', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'workflowstates/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'workflowstates/remove', params);
            },
            delete: function (params) {
                return $http.post(baseUrl + 'workflowstates/erase', params);
            },
            getItemByCode: function (code) {
                return $http.post(baseUrl + 'workflowstates/getitembycode', { Code: code });
            },
            getItemByWorkflowId: function (id) {
                return $http.get(baseUrl + 'workflowstates/getitembyworkflowid/' + id);
            }
        }

        this.logTasks = {
            getItems: function () {
                return $http.get(baseUrl + 'LogTask/getitems/');
            },
            getItemsByCode: function (id) {
                return $http.get(baseUrl + 'LogTask/getItemsByCode/' + id);
            },
            getItemsByDate: function (taskParameters) {
                return $http.post(baseUrl + 'LogTask/getItemsByDate/', taskParameters);
            },
            getTaskLogsFile: function (taskParameters) {
                return $http.get(baseUrl + 'LogTask/downloadTaskLogs', taskParameters);
            }
        }

        this.strategy = {
            getItems: function () {
                return $http.get(baseUrl + 'strategy/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'strategy/getitem/' + id);
            },
            //No tiene metodo en controller
            //getWorkflowTypeItems: function (workflowTypeCode) {
            //    return $http.post(baseUrl + 'strategy/workflowTypeItems', { Code: workflowTypeCode });
            //},
            getItemsByWorkflow: function (id) {
                return $http.get(baseUrl + 'strategy/getitemsbyworkflow/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'strategy/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'strategy/remove', params);
            },
            getStatesDetail: function (param) {
                return $http.post(baseUrl + 'strategy/strategydetail', param);
                //return $http.get(baseUrl + 'strategy/getstrategydetail/' + id);
            },
            getDependencies: function (id) {
                return $http.get(baseUrl + 'strategy/getdependencies/' + id);
            },
            getStatesFromDetails: function (param) {
                return $http.post(baseUrl + 'strategy/StatesFromByHeader', param);
            },
            getItemByCode: function (code) {
                return $http.post(baseUrl + 'strategy/getitembycode', { Code: code });
            }
        }

        this.statesByStrategy = {
            getItems: function () {
                return $http.get(baseUrl + 'statesbystrategy/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'statesbystrategy/getitem/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'statesbystrategy/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'statesbystrategy/remove', params);
            },
            getTeamMembers: function (Id) {
                return $http.get(baseUrl + 'statesbystrategyview/getstrategymembers/' + Id);
            },
            saveTeamMembers: function (params) {
                return $http.post(baseUrl + 'statesbystrategy/savestrategymembers', params);
            },
            saveDefault: function (params) {
                return $http.post(baseUrl + 'statesbystrategy/savedefault', params);
            },
            removeDefault: function (Id) {
                return $http.post(baseUrl + 'statesbystrategy/removeDefault', params);
            }
        }

        this.strategyTransAuto = {
            get: function (Id) {
                return $http.get(baseUrl + 'strategy/gettransitionauto/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'strategy/savetransitionauto', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'strategy/removetransitionauto', params);
            }
        }

        this.strategyTransManual = {
            get: function (Id) {
                return $http.get(baseUrl + 'strategy/gettransitionmanual/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'strategy/savetransitionmanual', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'strategy/removetransitionmanual', params);
            },
            GetTransitionDetailExecutorsbyManualTransact: function (Id) {
                return $http.get(baseUrl + 'strategy/GetTransitionDetailExecutorsbyManualTransact/' + Id);
            },
            GetExecutorsComponents: function () {
                return $http.get(baseUrl + 'strategy/GetExecutorsComponents');
            },
            saveComponentConfig: function (params) {
                return $http.post(baseUrl + 'strategy/saveComponentConfig', params);
            },
            removecompconf: function (params) {
                return $http.post(baseUrl + 'strategy/removecompconf', params);
            }
        }
        this.ssisHub = {
            getExecutions: function () {
                return $http.get(baseUrl + 'ssishub/getitems');
            }
        }

        this.alarmsByPerson = {
            getItem: function (Id) {
                return $http.get(baseUrl + 'alarmsbyperson/getitem/' + Id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'alarmsbyperson/getitems');
            },
            getAlarmsByPerson: function (Id) {
                return $http.get(baseUrl + 'alarmsbyperson/getalarmsbyperson/' + Id);
            },
            getItemsByWflPerson: function (param) {
                return $http.post(baseUrl + 'alarmsbyperson/itembywflperson/', param);
            }
        }

        this.deviceTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'devicetypes/getitems');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'devicetypes/getitem/' + Id);
            },
            save: function (param) {
                return $http.post(baseUrl + 'devicetypes/save/', param);
            }
        }

        this.PersonManagementTab = {
            getItems: function (Id) {
                return $http.get(baseUrl + 'personmanagementtab/getitems/' + Id);
            },
            getStates: function (Id) {
                return $http.get(baseUrl + 'personmanagementtab/getstates/' + Id);
            },
            getItemByManagementId: function (param) {
                return $http.post(baseUrl + 'personmanagementtab/itembymanagementid', param);
            },
            getStatesWflPerson: function (param) {
                return $http.post(baseUrl + 'personmanagementtab/statesbywflpersonuser', param);
            },
            getTopObjects: function (params) {
                return $http.post(baseUrl + 'personmanagementtab/topobjects/', params);
            }
        }

        this.campaignsByPerson = {
            getItems: function () {
                return $http.get(baseUrl + 'campaignsbyperson/getitems');
            },
            getCampaignsByPerson: function (Id) {
                return $http.get(baseUrl + 'campaignsbyperson/getcampaignsbyperson/' + Id);
            },
            getItemsByWflPerson: function (param) {
                return $http.post(baseUrl + 'campaignsbyperson/itemsbywflperson/', param);
            }
        }

        this.teamsByWorkflow = {
            getItems: function () {
                return $http.get(baseUrl + 'teamsbyworkflow/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'teamsbyworkflow/getitem/' + Id);
            },
            getWorkflowItems: function (workflowId) {
                return $http.get(baseUrl + 'teamsbyworkflow/getworkflowitems/' + workflowId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'teamsbyworkflow/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'teamsbyworkflow/remove', params);
            },
            getViewItem: function (params) {
                return $http.post(baseUrl + 'teamsbyworkflowview/itemworkflow/', params);
            },
            getWorkflowMembers: function (Id) {
                return $http.get(baseUrl + 'teamsbyworkflowview/getworkflowmembers/' + Id);
            },
            saveWorkflowMembers: function (params) {
                return $http.post(baseUrl + 'teamsbyworkflow/saveworkflowmembers', params);
            },
            getAssignedMembers: function (Id) {
                return $http.get(baseUrl + 'teamsbyworkflow/getassignedmembers/' + Id);
            }
        }

        this.Agency = {
            getItems: function () {
                return $http.get(baseUrl + 'agency/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'agency/getitem/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'agency/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'agency/remove', params);
            },
            getdisponiblesasignacion: function (Id) {
                return $http.get(baseUrl + 'agency/GetDisponiblesAsignacion/' + Id);
            }
        }

        this.AgencyAllocation = {
            getItems: function () {
                return $http.get(baseUrl + 'agencyallocation/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'agencyallocation/getitem/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'agencyallocation/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'agencyallocation/remove', params);
            },
            getAllocationDetail: function (Id) {
                return $http.get(baseUrl + 'agencyallocation/GetAllocationDetail/' + Id);
            },
            GetAvaibles: function (Id) {
                return $http.get(baseUrl + 'agencyallocation/GetAvaibles/' + Id);
            }
        }

        this.alarm = {
            getItem: function (Id) {
                return $http.get(baseUrl + 'alarm/getitem/' + Id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'alarm/getitems/');
            },
            getAlarms: function () {
                return $http.get(baseUrl + 'alarm/getalarms/');
            },
            getItemsByWorkflow: function (Id) {
                return $http.get(baseUrl + 'alarm/getitemsbyworkflow/' + Id);
            },
            getItemsByWorkflowUser: function (Id) {
                return $http.get(baseUrl + 'alarm/getitemsbyworkflowuser/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'alarm/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'alarm/remove', params);
            },
            saveAlarmSchedule: function (params) {
                return $http.post(baseUrl + 'alarm/savealarmschedule', params);
            }
            //,
            //alarmList: function (params) {
            //    return $http.post(baseUrl + 'alarm/AlarmsList', params);
            //}
        }

        this.manualCampaigns = {
            getItems: function () {
                return $http.get(baseUrl + 'manualcampaigns/getitems/');
            },
            getItemsByUser: function () {
                return $http.get(baseUrl + 'manualcampaigns/getitemsbyuser/');
            },
            hasCampaignPending: function () {
                return $http.get(baseUrl + 'manualcampaigns/hasCampaignPending/');
            },
            getItemsByUserPage: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/getitemsbyuserpage', params);
            },
            getItemsByUserCmpId: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/getitemsbyusercmpid/' + Id);
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/getitem/' + Id);
            },
            getCampaignsByStage: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/getcampaignsbystage/' + Id);
            },
            getItemsByWorkflow: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/getitemsbyworkflow/' + Id);
            },
            getItemsByWorkflowUser: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/getitemsbyworkflowuser/' + Id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/save', params);
            },
            saveWithSort: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/savewithsort', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/remove', params);
            },
            saveAlarmSchedule: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/savealarmschedule', params);
            },
            saveOrder: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/changeorder', params);
            },
            changeMultipleOrder: function (param) {
                return $http.post(baseUrl + 'manualcampaigns/changemultipleorder', param);
            },
            thereEmptyCampaignsForTheUser: function () {
                return $http.get(baseUrl + 'manualcampaigns/thereemptycampaignsfortheuser/');
            },
            getSegmentAllocationByCampaign: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/getsegmentallocationbycampaign/' + Id);
            },
            GetPotencialQrys: function (Id) {
                return $http.get(baseUrl + 'manualcampaigns/GetPotencialQrys/' + Id);

            }
            //,
            //list: function (params) {
            //    return $http.post(baseUrl + 'manualcampaigns/list/', params);
            //}
        }

        this.sweepingType = {
            getItem: function (id) {
                return $http.get(baseUrl + 'SweepingType/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'SweepingType/getitems/');
            }
        }

        this.eventTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'eventtype/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'eventtype/getitems/');
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'eventtype/getdependencies/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'eventtype/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'eventtype/remove', params);
            },
            getWorkflowTypeItems: function (params) {
                return $http.post(baseUrl + 'eventtype/workflowtypeitems', { Code: params });//'"' + params + '"');
            },
            saveWithConsequents: function (params) {
                return $http.post(baseUrl + 'eventtype/SaveWithConsequents', params);
            }
        }

        this.autoCampaigns = {
            getItems: function () {
                return $http.get(baseUrl + 'autocampaigns/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'autocampaigns/getitem/' + Id);
            },
            getItemsByWorkflow: function (Id) {
                return $http.get(baseUrl + 'autocampaigns/getitemsbyworkflow/' + Id);
            },
            getItemsByWorkflowUser: function (Id) {
                return $http.get(baseUrl + 'autocampaigns/getitemsbyworkflowuser/' + Id);
            },
            //getCampaignsByStage: function (Id) {
            //    return $http.get(baseUrl + 'autocampaigns/getcampaignsbystage/' + Id);
            //},
            save: function (params) {
                return $http.post(baseUrl + 'autocampaigns/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'autocampaigns/remove', params);
            },
            executeCampaignOnline: function (params) {
                return $http.post(baseUrl + 'autocampaigns/executecampaignonline', params);
            },
            isExecCampaignOnline: function () {
                return $http.post(baseUrl + 'autocampaigns/isexeccampaignonline');
            }
            //,
            //list: function (params) {
            //    return $http.post(baseUrl + 'autocampaigns/list/', params);
            //}
        }

        this.managementMap = {
            getItemsByStage: function (stageId) {
                return $http.get(baseUrl + 'managementmap/GetStageQuantities/' + stageId);
            },
            getManagementInfoByStage: function (stageId) {
                return $http.get(baseUrl + 'managementmap/GetManagementInfoByStage/' + stageId);
            },
            getItemsByState: function (param) {
                return $http.post(baseUrl + 'managementmap/resolveitemsbystate/', param);
            },
            getStageQuantitiesManagementInfo: function (param) {
                return $http.post(baseUrl + 'managementmap/GetStageQuantitiesManagementInfo/', param);
            }
        }

        this.script = {
            getItem: function (Id) {
                return $http.get(baseUrl + 'script/getitem/' + Id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'script/getitems/');
            },
            getDependencies: function () {
                return $http.get(baseUrl + 'script/getdependencies/');
            },
            searchCode: function (code) {
                return $http.post(baseUrl + 'script/searchCode', { Code: code });
            },
            getWorkflowTypeItems: function (workflowTypeCode) {
                return $http.post(baseUrl + 'script/workflowTypeItems', { Code: workflowTypeCode });
            },
            save: function (params) {
                return $http.post(baseUrl + 'script/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'script/remove', params);
            }
        }

        this.companies = {
            getItem: function (id) {
                return $http.get(baseUrl + 'companies/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'companies/getitems/');
            },
            getItemsBySchema: function (schema) {
                $http.defaults.headers.common.qpschema = schema.DbSchema;
                return $http.get(baseUrl + 'companies/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'companies/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'companies/remove', params);
            },
            getItemsDyn: function (schema) {
                $http.defaults.headers.common.qpschema = schema;
                return $http.get(baseUrl + 'companies/getitemsdyn/');
            }
        }

        this.portfolios = {
            getItem: function (id) {
                return $http.get(baseUrl + 'portfolios/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'portfolios/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'portfolios/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'portfolios/remove', params);
            }
        }

        this.productGroups = {
            getItem: function (id) {
                return $http.get(baseUrl + 'productgroups/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'productgroups/getitems/');
            },
            getCompanyItems: function (companyId) {
                return $http.get(baseUrl + 'productgroups/getcompanyitems/' + companyId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'productgroups/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'productgroups/remove', params);
            }
        }

        this.productTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'metproducttypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'metproducttypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'metproducttypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'metproducttypes/remove', params);
            }
        }

        this.products = {
            getItem: function (id) {
                return $http.get(baseUrl + 'products/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'products/getitems/');
            },
            getProductGroupItems: function (productType) {
                return $http.get(baseUrl + 'products/getproductgroupitems/' + productType);
            },
            save: function (params) {
                return $http.post(baseUrl + 'products/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'products/remove', params);
            }
        }

        this.branches = {
            getItem: function (id) {
                return $http.get(baseUrl + 'branches/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'branches/getitems/');
            },
            getZoneItems: function (zoneId) {
                return $http.get(baseUrl + 'branches/getzoneitems/' + zoneId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'branches/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'branches/remove', params);
            }
        }

        this.segments = {
            getItem: function (id) {
                return $http.get(baseUrl + 'segments/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'segments/getitems/');
            },
            getCompanyItems: function (companyId) {
                return $http.get(baseUrl + 'segments/getcompanyitems/' + companyId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'segments/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'segments/remove', params);
            }
        }

        this.zones = {
            getItem: function (id) {
                return $http.get(baseUrl + 'zones/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'zones/getitems/');
            },
            getCompanyItems: function (companyId) {
                return $http.get(baseUrl + 'zones/getcompanyitems/' + companyId);
            },
            getActiveCompanyItems: function (companyId) {
                return $http.get(baseUrl + 'zones/GetActiveCompanyItems/' + companyId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'zones/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'zones/remove', params);
            }
        }

        this.subSegments = {
            getItem: function (id) {
                return $http.get(baseUrl + 'subsegments/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'subsegments/getitems/');
            },
            getSegmentItems: function (segmentId) {
                return $http.get(baseUrl + 'subsegments/getsegmentitems/' + segmentId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'subsegments/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'subsegments/remove', params);
            }
        }

        this.economic_groups = {
            getItem: function (id) {
                return $http.get(baseUrl + 'economicgroups/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'economicgroups/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'economicgroups/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'economicgroups/remove', params);
            },
            getItemsPage: function (params) {
                return $http.post(baseUrl + 'economicgroups/getitemspage', params);
            }
        }

        this.currencies = {
            getItem: function (id) {
                return $http.get(baseUrl + 'currencies/getitem/' + id);
            },
            getExchangeRateHistory: function (id) {
                return $http.get(baseUrl + 'currencies/getExchangeRateHistory/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'currencies/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'currencies/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'currencies/remove', params);
            }
        }

        this.paymentPromises = {
            getItems: function (personId) {
                return $http.get(baseUrl + 'paymentPromises/getitems/' + personId);
            },
            getItemsCoOwn: function (personId) {
                return $http.get(baseUrl + 'paymentPromises/getitemsCoOwn/' + personId);
            },
            getItem: function (promiseId) {
                return $http.get(baseUrl + 'paymentPromises/getitem/' + promiseId);
            },
            getParams: function (personId) {
                return $http.get(baseUrl + 'paymentPromisesparams/getitem/' + personId);
            },
            obtainItems: function (params) {
                return $http.post(baseUrl + 'paymentPromisesparams/obtaintitem/', params);
            },
            obtainDetailsSegments: function (params) {
                return $http.post(baseUrl + 'paymentPromisesparams/obtaindetailsegments/', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'paymentPromises/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'paymentPromises/remove', params);
            },
            disable: function (params) {
                return $http.post(baseUrl + 'paymentPromises/disable', params);
            },
            reset: function (params) {
                return $http.post(baseUrl + 'paymentPromises/reset', params);
            }
        }

        this.paymentPromisesDetail = {
            getItems: function (promiseId) {
                return $http.get(baseUrl + 'paymentPromiseDetail/getitems/' + promiseId);
            },
            getItem: function (detailId) {
                return $http.get(baseUrl + 'paymentPromiseDetail/getitem/' + detailId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'paymentPromiseDetail/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'paymentPromiseDetail/remove', params);
            },
            obtainItems: function (params) {
                return $http.post(baseUrl + 'paymentPromiseDetail/obtainItems', params);
            },
            obtainItemsCoOwn: function (params) {
                return $http.post(baseUrl + 'paymentPromiseDetail/ObtainItemsCoOwn', params);
            }
        }

        this.judgement_types = {
            getItems: function () {
                return $http.get(baseUrl + 'judgmenttypes/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'judgmenttypes/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'judgmenttypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'judgmenttypes/remove', params);
            }
        }

        this.justifications = {
            getItems: function () {
                return $http.get(baseUrl + 'justifications/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'justifications/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'justifications/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'justifications/remove', params);
            }
        }

        this.justActionTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'Justactiontypes/getitems/');
            },
            getItemsByActType: function (id) {
                return $http.get(baseUrl + 'Justactiontypes/getitemsbyacttype/' + id);
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'Justactiontypes/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'Justactiontypes/save', params);
            },

            saveJust: function (params) {
                return $http.post(baseUrl + 'Justactiontypes/savejust', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'Justactiontypes/remove', params);
            },
            removeByJust: function (params) {
                return $http.post(baseUrl + 'Justactiontypes/removebyjust', params);
            }
        }

        this.userCampaign = {
            getItems: function () {
                return $http.get(baseUrl + 'usercampaign/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'usercampaign/getitem/' + Id);
            },
            getCampaignsByUser: function (Id) {
                return $http.get(baseUrl + 'usercampaign/getcampaignsbyuser/' + Id);
            },
            getCampaignsHeader: function (Id) {
                return $http.get(baseUrl + 'usercampaign/getcampaignsheader/' + Id);
            },
            list: function (params) {
                return $http.post(baseUrl + 'manualcampaigns/list/', params);
            }
            //,
            //getCampaignsByStage: function (Id) {
            //    return $http.get(baseUrl + 'autocampaigns/getcampaignsbystage/' + Id);
            //}
        }
        this.rule = {
            getItem: function (ruleId) {
                return $http.get(baseUrl + 'rule/getitem/' + ruleId)
            },
            getMetadataTypes: function () {
                return $http.get(baseUrl + 'rule/getruletypes/')
            },
            getMetadataType: function (ruleId) {
                return $http.get(baseUrl + 'rule/getruletypeofrule/' + ruleId)
            },
            get: function (params) {
                return $http.post(baseUrl + 'rule/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'rule/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'rule/remove', params);
            },
            saveAll: function (params) {
                return $http.post(baseUrl + 'rule/saveall', params);
            },
            enable: function (ruleId) {
                return $http.post(baseUrl + 'rule/enablerule', { Id: ruleId });
            },
            disable: function (ruleId) {
                return $http.post(baseUrl + 'rule/disablerule', { Id: ruleId });
            },
            updateQueriesFromWorkflow: function (workflowId) {
                return $http.post(baseUrl + 'rule/updaterulesqueriesfromworkflow', workflowId);
            },
            updateQuery: function (params) {
                return $http.post(baseUrl + 'rule/updaterulequery', params);
            }
        }
        this.assimilationRuleStage = {
            get: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/save', params);
            },
            create: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/create', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/remove', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/clone', params);
            },
            copy: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/copy', params);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'assimilationrulestage/createfromfilters', params);
            },
            preview: function (id) {
                return $http.get(baseUrl + 'assimilationrulestage/preview/' + id);
            }
        }
        this.alarmRule = {
            get: function (params) {
                return $http.post(baseUrl + 'alarmrule/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'alarmrule/save', params);
            },
            create: function (params) {
                return $http.post(baseUrl + 'alarmrule/create', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'alarmrule/remove', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'alarmrule/clone', params);
            },
            copy: function (params) {
                return $http.post(baseUrl + 'alarmrule/copy', params);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'alarmrule/createfromfilters', params);
            },
            preview: function (id) {
                return $http.get(baseUrl + 'alarmrule/preview/' + id);
            }
        }
        this.asignationRule = {
            get: function (params) {
                return $http.post(baseUrl + 'asignationrule/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'asignationrule/save', params);
            },
            create: function (params) {
                return $http.post(baseUrl + 'asignationrule/create', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'asignationrule/remove', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'asignationrule/clone', params);
            },
            copy: function (params) {
                return $http.post(baseUrl + 'asignationrule/copy', params);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'asignationrule/createfromfilters', params);
            },
            preview: function (id) {
                return $http.get(baseUrl + 'asignationrule/preview/' + id);
            }
        }
        this.manualCampaignRule = {
            get: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/save', params);
            },
            create: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/create', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/remove', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/clone', params);
            },
            copy: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/copy', params);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'manualcampaignrule/createfromfilters', params);
            },
            preview: function (id) {
                return $http.get(baseUrl + 'manualcampaignrule/preview/' + id);
            }
        }
        this.autoCampaignRule = {
            get: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/save', params);
            },
            create: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/create', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/remove', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/clone', params);
            },
            copy: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/copy', params);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'autocampaignrule/createfromfilters', params);
            },
            preview: function (id) {
                return $http.get(baseUrl + 'autocampaignrule/preview/' + id);
            }
        }
        this.transitionRuleAutomatic = {
            get: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/rules', params)
            },
            save: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/save', params);
            },
            create: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/create', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/remove', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/clone', params);
            },
            copy: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/copy', params);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'transitionruleautomatic/createfromfilters', params);
            },
            preview: function (id) {
                return $http.get(baseUrl + 'transitionruleautomatic/preview/' + id);
            }
        }
        this.attachments = {
            getItem: function (id) {
                return $http.get(baseUrl + 'attachments/GetItem/' + id);
            },
            getConfiguration: function () {
                return $http.get(baseUrl + 'attachments/getconfiguration');
            },
            getItemsByPerson: function (id) {
                return $http.get(baseUrl + 'attachments/getitemsbyperson/' + id);
            },
            getItemsByAction: function (id) {
                return $http.get(baseUrl + 'attachments/getitemsbyaction/' + id);
            },
            search: function (terms) {
                return $http.post(baseUrl + 'attachments/search', { Code: terms });
            },
            save: function (attach) {
                return $http.post(baseUrl + 'attachments/save', attach);
            },
            SaveAttachs: function (attachs) {
                return $http.post(baseUrl + 'attachments/SaveAttachs', attachs);
            },
            searchGestDoc: function (filter) {
                return $http.post(baseUrl + 'ViewAttachments/search', filter);
            },
            remove: function (attach) {
                return $http.post(baseUrl + 'attachments/remove', attach);
            },
            //getItem: function (id) {
            //    return $http.get(baseUrl + 'attachments/getitem/' + id);
            //},
            download: function (id) {
                return $http.get(baseUrl + 'attachments/download/' + id, { responseType: 'blob' });
            }
        };

        this.AttachmentsType = {
            GetItemsWithWfl: function (id) {
                return $http.get(baseUrl + 'AttachmentsType/GetItemsWithWfl/' + id);
            },
            getItems: function (id) {
                return $http.get(baseUrl + 'AttachmentsType/Getitems');
            },

        }

        this.campaignsAutoByPerson = {
            getItems: function () {
                return $http.get(baseUrl + 'campaignsautobyperson/getitems');
            },
            getCampaignsByPerson: function (Id) {
                return $http.get(baseUrl + 'campaignsautobyperson/getcampaignsbyperson/' + Id);
            },
            getItemsByWflPerson: function (param) {
                return $http.post(baseUrl + 'campaignsautobyperson/itemsbywflperson/', param);
            },
            getItemsByWflPersonObject: function (param) {
                return $http.post(baseUrl + 'campaignsautobyperson/itemsbywflpersonobject/', param);
            }
        }

        this.manualCampaignsWorked = {
            getItems: function () {
                return $http.get(baseUrl + 'manualcampaignsworked/getitems/');
            },
            getItem: function (Id) {
                return $http.get(baseUrl + 'manualcampaignsworked/getitem/' + Id);
            }
        }

        this.judgments = {
            getItems: function () {
                return $http.get(baseUrl + 'judgments/getitems/');
            },
            getItemsByPerson: function (personId) {
                return $http.get(baseUrl + 'judgments/getitemsbyperson/' + personId);
            },
            getItem: function (judgmentId) {
                return $http.get(baseUrl + 'judgments/getitem/' + judgmentId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'judgments/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'judgments/remove', params);
            }
        }

        this.judgmentTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'judgmenttypes/getitems/');
            },
            getItem: function (judgmentTypeId) {
                return $http.get(baseUrl + 'judgmenttypes/getitem/' + judgmentTypeId);
            },
            save: function (params) {
                return $http.post(baseUrl + 'judgmenttypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'judgmenttypes/remove', params);
            }
        }
        this.judgmentsByAccounts = {
            getItemsByJudgment: function (params) {
                return $http.get(baseUrl + 'judgmentsbyaccounts/getitemsbyjudgment/' + params);
            },
            update: function (params) {
                return $http.post(baseUrl + 'judgmentsbyaccounts/update', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'judgmentsbyaccounts/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'judgmentsbyaccounts/remove', params);
            }
        }
        this.prosecution = {
            getItemsByJudgment: function (params) {
                return $http.get(baseUrl + 'prosecutions/getitemsbyjudgment/' + params);
            },
            getTypesByJudgmentType: function (params) {
                return $http.get(baseUrl + 'prosecutiontypes/getitemsbyjudgmenttype/' + params);
            },
            getItem: function (params) {
                return $http.get(baseUrl + 'prosecutions/getitem/' + params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'prosecutions/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'prosecutions/remove', params);
            }
        }

        this.emerixObject = {
            getItem: function (params) {
                return $http.get(baseUrl + 'emerixobject/getitem/' + params);
            },
            getItems: function () {
                return $http.get(baseUrl + 'emerixobject/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'emerixobject/save', params);
            },
            saveObject: function (params) {
                return $http.post(baseUrl + 'emerixobject/saveobject', params);
            },
            saveManualChange: function (params) {
                return $http.post(baseUrl + 'manualchanges/save', params);
            },
            getItemLider: function (params) {
                return $http.get(baseUrl + 'emerixobject/getitemleader/' + params);
            },
            searchItem: function (params) {
                return $http.post(baseUrl + 'emerixobject/searchitem/', params);
            },
            getTopObjects: function (params) {
                return $http.post(baseUrl + 'emerixobject/topobjects/', params);
            },
            GetObjectsByWfl: function (params) {
                return $http.post(baseUrl + 'emerixobject/GetObjectsByWfl/', params);
            }
        }

        /*  this.agreementTypes = {
              getItem: function (id) {
                  return $http.get(baseUrl + 'agreementtypes/getitem/' + id);
              },
              getItems: function () {
                  return $http.get(baseUrl + 'agreementtypes/getitems/');
              },
              save: function (params) {
                  return $http.post(baseUrl + 'agreementtypes/save', params);
              },
              remove: function (params) {
                  return $http.post(baseUrl + 'agreementtypes/remove', params);
              }
          }*/

        /*   this.activeAgreements = {
               getItem: function (id) {
                   return $http.get(baseUrl + 'activeagreements/getitem/' + id);
               },
               getItems: function () {
                   return $http.get(baseUrl + 'activeagreements/getitems/');
               },
               getItemsByClient: function (id) {
                   return $http.get(baseUrl + 'activeagreements/getitemsbyclient/' + id);
               },
               save: function (params) {
                   return $http.post(baseUrl + 'activeagreements/save', params);
               },
               remove: function (params) {
                   return $http.post(baseUrl + 'activeagreements/remove', params);
               },
               calculate: function (params) {
                   return $http.post(baseUrl + 'activeagreements/calculate', params);
               }
           }*/

        this.historicAgreements = {
            getItem: function (id) {
                return $http.get(baseUrl + 'historicagreements/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'historicagreements/getitems/');
            },
            getItemsByClient: function (id) {
                return $http.get(baseUrl + 'historicagreements/getitemsbyclient/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'historicagreements/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'historicagreements/remove', params);
            }
        }

        this.activeAgreementByAccount = {
            getItemsByAgreement: function (params) {
                return $http.get(baseUrl + 'activeagreementbyaccount/getitemsbyagreement/' + params);
            },
            update: function (params) {
                return $http.post(baseUrl + 'activeagreementbyaccount/update', params);
            }
        }

        this.historicAgreementByAccount = {
            getItemsByAgreement: function (params) {
                return $http.get(baseUrl + 'historicagreementbyaccount/getitemsbyagreement/' + params);
            },
            update: function (params) {
                return $http.post(baseUrl + 'historicagreementbyaccount/update', params);
            }
        },

            this.notifications = {
                getChatThreads: function () {
                    return $http.get(baseUrl + 'notifications/getchatthreads');
                },
                getUserChat: function (id) {
                    return $http.get(baseUrl + 'notifications/getuserchat/' + id);
                },
                getRoleChat: function (id) {
                    return $http.get(baseUrl + 'notifications/getrolechat/' + id);

                },
                getTeamChat: function (id) {
                    return $http.get(baseUrl + 'notifications/getteamchat/' + id);
                },
                sendChatMessage: function (message) {
                    return $http.post(baseUrl + 'notifications/sendchatmessage', message);
                },
                markAsRead: function (thread) {
                    return $http.post(baseUrl + 'notifications/markasread', thread);
                },
                getEmailTemplatesList: function () {
                    return $http.get(baseUrl + 'emailtemplates/getlist');
                },
                getEmailEventsList: function () {
                    return $http.get(baseUrl + 'emailtemplates/geteventslist');
                },
                saveEmailTemplate: function (emailTemplate) {
                    return $http.post(baseUrl + 'emailtemplates/save', emailTemplate);
                }
            }

        this.activeAgreementFees = {
            getItem: function (id) {
                return $http.get(baseUrl + 'activeagreementfees/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'activeagreementfees/getitems/');
            },
            getItemsByAgreement: function (id) {
                return $http.get(baseUrl + 'activeagreementfees/getitemsbyagreement/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'activeagreementfees/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'activeagreementfees/remove', params);
            },
            calculate: function (id) {
                return $http.post(baseUrl + 'activeagreementfees/calculate/' + id);
            }
        }

        this.calendar = {
            remainderList: function (filter) {
                return $http.post(baseUrl + "calendar/remainderlist", filter);
            },
            getUsersAndTeams: function () {
                return $http.get(baseUrl + "calendar/getusersandteams");
            },
            saveRemainder: function (remainder) {
                return $http.post(baseUrl + "calendar/saveremainder", remainder);
            },
            eventList: function (filter) {
                return $http.post(baseUrl + "calendar/eventlist", filter);
            },
            cancelRemainder: function (remainder) {
                return $http.post(baseUrl + "calendar/cancelremainder", remainder);
            }
        }

        this.scopeMetadata = {
            getItem: function (id) {
                return $http.get(baseUrl + 'scopemetadata/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'scopemetadata/getitems/');
            },
            getItemsByClient: function (id) {
                return $http.get(baseUrl + 'scopemetadata/getitemsbyclient/' + id);
            },
            getallitems: function () {
                return $http.get(baseUrl + 'scopemetadata/getallitems/');
            },
            getItemsByWflPerson: function (param) {
                return $http.post(baseUrl + 'scopemetadata/itemsbywflperson/', param);
            }
        }

        this.forms = {
            build: function (data) {
                return $http.post(baseUrl + 'formsbuilder/build', data);
            },
            saveData: function (frm) {
                return $http.post(baseUrl + 'formsbuilder/save', frm);
            },
            deleteData: function (frm) {
                return $http.post(baseUrl + 'formsbuilder/delete', frm);
            },
            getItems: function () {
                return $http.get(baseUrl + 'forms/getitems');
            },
            /**
             * Retorna los formularios mencionados en el array de ids
             * @param {Array<number>} formIds Array de ids de formularios
             */
            getItemsByFormIds: function (formIds) {
                formIds = angular.isArray(formIds) ? formIds : [];
                var uriParams = null;
                for (var i = 0; i < formIds.length; i++) {
                    var formId = formIds[i];
                    if (!uriParams) {
                        uriParams = 'formIds=' + formId;
                    }
                    else {
                        uriParams += '&formIds=' + formId;
                    }
                }

                return $http.get(baseUrl +
                    'forms/getitemsbyformids?' + (!!uriParams ? uriParams : 'formIds=-1'));
            },
            getItemsByEntity: function (params) {
                return $http.post(baseUrl + 'forms/getitemsbyentity', params);       // 20161026
            },
            getItemsByGroup: function (params) {
                return $http.post(baseUrl + 'forms/getitemsbygroup', params);       // 20161026
            },
            getFields: function (formId) {
                return $http.get(baseUrl + 'formsfields/getitemsbyform/' + formId);
            },
            saveAssigned: function (param) {
                return $http.post(baseUrl + 'forms/saveassigned', param);
            },
            save: function (form) {
                return $http.post(baseUrl + 'forms/save', form);
            },
            remove: function (form) {
                return $http.post(baseUrl + 'forms/remove', form);
            },
            getFormFieldsGroups: function (formId) {
                return $http.get(baseUrl + 'formsfields/getgroups/' + formId);
            },
            getFieldsByTypes: function (formId) {
                return $http.get(baseUrl + 'formsfields/GetFieldsByTypes/' + formId);
            },
            getFieldByFormEntity: function (param) {
                return $http.post(baseUrl + 'formsfields/fieldByFormEntity', param);
            },
            saveField: function (field) {
                return $http.post(baseUrl + 'formsfields/save', field);
            },
            removeField: function (field) {
                return $http.post(baseUrl + 'formsfields/remove', field);
            },
            changeOrderFields: function (fields) {
                return $http.post(baseUrl + 'formsfields/changeorder', fields);
            },
            createWithFields: function (form) {
                return $http.post(baseUrl + 'forms/createwithfields', form);
            },
            GetFormFieldsAsocByForm: function (formId) {
                return $http.get(baseUrl + 'forms/GetFormFieldsAsocByForm/' + formId);
            },
            GetItemsByCode: function (code) {
                return $http.get(baseUrl + 'forms/GetItemsByCode/' + code);
            },
            getItem: function (formId) {
                return $http.get(baseUrl + 'forms/getitem/' + formId);
            }
        }

        this.competenceGroups = {
            getItem: function (competenceGroupId) {
                return $http.get(baseUrl + 'competencegroups/getitem/' + competenceGroupId);
            },
            getItems: function () {
                return $http.get(baseUrl + 'competencegroups/getitems');
            },
            getCompanyItems: function (companyId) {
                return $http.get(baseUrl + 'competencegroups/getcompanyitems/' + companyId);
            },
            save: function (competenceGroup) {
                return $http.post(baseUrl + 'competencegroups/save', competenceGroup);
            },
            delete: function (competenceGroup) {
                return $http.post(baseUrl + 'competencegroups/delete', competenceGroup);
            }
        }

        this.competenceGroupAssigments = {
            getItem: function (competenceGroupAssigmentId) {
                return $http.get(baseUrl + 'competencegroupassignations/getitem/' + competenceGroupAssigmentId);
            },
            getItems: function (competenceGroupId) {
                return $http.get(baseUrl + 'competencegroupassignations/getitems/' + competenceGroupId);
            },
            save: function (competenceGroupAssigment) {
                return $http.post(baseUrl + 'competencegroupassignations/save', competenceGroupAssigment);
            },
            remove: function (competenceGroupAssigment) {
                return $http.post(baseUrl + 'competencegroupassignations/delete', competenceGroupAssigment);
            }
        }

        this.competenceGroupVariables = {
            getItem: function (competenceGroupVariableId) {
                return $http.get(baseUrl + 'competencegroupvariables/getitem/' + competenceGroupVariableId);
            },
            getItems: function () {
                return $http.get(baseUrl + 'competencegroupvariables/getitems');
            },
            getValues: function (dataConfig) {
                return $http.post(baseUrl + 'competencegroupvariables/attributevaluelist', dataConfig);
            },
            save: function (competenceGroupVariable) {
                return $http.post(baseUrl + 'competencegroupvariables/save', competenceGroupVariable);
            },
            remove: function (competenceGroupVariable) {
                return $http.post(baseUrl + 'competencegroupvariables/remove', competenceGroupVariable);
            }
        }

        //this.allocationTypesForAlarms = {
        //    getAvailableItems: function (params) {
        //        return $http.get(baseUrl + 'AllocationTypesForAlarms/GetAvailableItems/' + params);
        //    }
        //    , getAssignedItems: function (params) {
        //        return $http.get(baseUrl + 'allocationtypesforalarms/getassigneditems/' + params);
        //    }
        //    , save: function (params) {
        //        return $http.post(baseUrl + 'allocationtypesforalarms/save', params);
        //    }
        //    , remove: function (params) {
        //        return $http.post(baseUrl + 'allocationtypesforalarms/remove', params);
        //    }
        //}
        //this.allocationTypesForActions = {
        //    getAvailableItems: function (params) {
        //        return $http.get(baseUrl + 'allocationtypesforactions/getavailableitems/' + params);
        //    }
        //    , getAssignedItems: function (params) {
        //        return $http.get(baseUrl + 'allocationtypesforactions/getassigneditems/' + params);
        //    }
        //    , save: function (params) {
        //        return $http.post(baseUrl + 'allocationtypesforactions/save', params);
        //    }
        //    , remove: function (params) {
        //        return $http.post(baseUrl + 'allocationtypesforactions/remove', params);
        //    }
        //}
        //this.allocationTypesForEvents = {
        //    getAvailableItems: function (params) {
        //        return $http.get(baseUrl + 'allocationtypesforevents/getavailableitems/' + params);
        //    }
        //    , getAssignedItems: function (params) {
        //        return $http.get(baseUrl + 'allocationtypesforevents/getassigneditems/' + params);
        //    }
        //    , save: function (params) {
        //        return $http.post(baseUrl + 'allocationtypesforevents/save', params);
        //    }
        //    , remove: function (params) {
        //        return $http.post(baseUrl + 'allocationtypesforevents/remove', params);
        //    }
        //}

        this.agentTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'agenttypes/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'agenttypes/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'agenttypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'agenttypes/remove', params);
            }
        }

        this.agents = {
            getItems: function () {
                return $http.get(baseUrl + 'agents/getitems/');
            },
            getagencies: function () {
                return $http.get(baseUrl + 'agents/getagencies/');
            },
            getagenciesByAssignCode: function (id) {
                return $http.get(baseUrl + 'agents/getagenciesByAssignCode/' + id);
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'agents/getitem/' + id);
            },
            getAgentTypeItems: function (id) {
                return $http.get(baseUrl + 'agents/getagenttypeitems/' + id);
            },
            //getZoneItems: function (zoneId) {
            //    return $http.get(baseUrl + 'AgentsByZone/getzoneitems/' + zoneId);
            //},
            save: function (params) {
                return $http.post(baseUrl + 'agents/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'agents/remove', params);
            }
            , GetItemsByCode: function (code) {
                return $http.get(baseUrl + 'agents/GetItemsByCode/' + code);
            }

        }

        //this.zonesByAgent = {
        //    get: function (AgentId) {
        //        return $http.get(baseUrl + 'zonesbyagent/GetItemsByAgent/' + AgentId);
        //    },
        //    save: function (params) {
        //        return $http.post(baseUrl + 'zonesbyagent/SaveItems', params);
        //    }
        //};

        this.instalation = {
            getData: function () {
                return $http.get(baseUrl + 'instalation/getItems');
            },
            saveData: function (params) {
                return $http.post(baseUrl + 'instalation/save', params);
            },
            changePhoto: function (params) {
                return $http.post(baseUrl + 'instalation/changePhoto', params);
            }
        };

        this.implementationParameters = {
            getDataByCode: function (code) {
                return $http.post(baseUrl + 'ImplementationParameters/getItem', code);
            },
            getData: function () {
                return $http.get(baseUrl + 'ImplementationParameters/getItems');
            },
            getGroups: function () {
                return $http.get(baseUrl + 'ImplementationParameters/GetGroups');
            },
            save: function (params) {
                return $http.post(baseUrl + 'ImplementationParameters/save', params);
            }
        };

        this.securityParams = {
            getParam: function () {
                return $http.get(baseUrl + 'securityparams/getparam');
            },
            save: function (params) {
                return $http.post(baseUrl + 'securityparams/save', params);
            }
        };

        this.businessTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'BussinessTypes/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'BussinessTypes/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'BussinessTypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'BussinessTypes/remove', params);
            }
        }

        this.workingDays = {
            getData: function () {
                return $http.get(baseUrl + 'workingDays/getItems');
            },
            saveData: function (params) {
                return $http.post(baseUrl + 'workingDays/save', params);
            }
        };

        this.workflowTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'WorkflowTypes/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'WorkflowTypes/getitem/' + id);
            },
            getItemsByUser: function (id) {
                return $http.get(baseUrl + 'WorkflowTypes/getitemsbyuser/');
            },
            getItemsByBusiness: function (code) {
                return $http.get(baseUrl + 'WorkflowTypes/getWorkflowTypesByBusinessCode/' + code);
            },
            getItemByWorkflowId: function (id) {
                return $http.get(baseUrl + 'WorkflowTypes/getitembyworkflowid/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'WorkflowTypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'WorkflowTypes/remove', params);
            },
            /**
             * Retorna el tipo de workflow a través de su código.
             * @param {string} workflowTypeCode Código de metadata del tipo de workflow.
             */
            getItemByCode: function (workflowTypeCode) {
                return $http.get(baseUrl + 'workflowtypes/getitem' +
                    '?workflowTypeCode=' + (!!workflowTypeCode ? workflowTypeCode : ''));
            }
        };

        this.holidays = {
            getItems: function () {
                return $http.get(baseUrl + 'Holidays/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'Holidays/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'Holidays/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'Holidays/remove', params);
            }
        };

        this.SystemParameter = {
            getItems: function () {
                return $http.get(baseUrl + 'SystemParameter/getitems/');
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'SystemParameter/getitem/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'SystemParameter/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'SystemParameter/remove', params);
            },
            getItemByCode: function (code) {
                return $http.post(baseUrl + 'SystemParameter/itembycode', { Code: code });
            }
        };

        this.ModelDocumentTemplate = {
            getItem: function (id) {
                return $http.get(baseUrl + 'ModelDocumentTemplate/getitem/' + id);
            },
            GetByCode: function (id) {
                return $http.get(baseUrl + 'ModelDocumentTemplate/GetByCode/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'ModelDocumentTemplate/getitems');
            },
        }

        this.persondocsmodel = {
            getItem: function (id) {
                return $http.get(baseUrl + 'persondocsmodel/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'persondocsmodel/getitems');
            },
            getByMetadataCodeAndCompanies: function (item) {
                return $http.post(baseUrl + 'persondocsmodel/GetByMetadataCodeAndCompanies', item);
            },
            getByCompanyAndMetadataModel: function (item) {
                return $http.post(baseUrl + 'persondocsmodel/GetByCompanyAndMetadataModel', item);
            },
            getDocModelsByPay: function (id) {
                return $http.get(baseUrl + 'persondocsmodel/GetDocModelsByPay/' + id);
            },
            save: function (row) {
                return $http.post(baseUrl + 'persondocsmodel/save', row);
            },
            remove: function (row) {
                return $http.post(baseUrl + 'persondocsmodel/remove', row);
            },
            checkCode: function (code) {
                return $http.get(baseUrl + 'persondocsmodel/checkcode/' + code);
            },
            getDocModelsByRules: function (item) {
                return $http.post(baseUrl + 'persondocsmodel/GetDocModelsByRules', item);
            },
            download: function (id) {
                return $http.get(baseUrl + 'persondocsmodel/download/' + id, { responseType: 'blob' });
            }
        }

        this.BatchParams = {
            getData: function () {
                return $http.get(baseUrl + 'BatchParams/getItems');
            },
            saveData: function (params) {
                return $http.post(baseUrl + 'BatchParams/save', params);
            }
        };

        this.wflChangeTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'wflchangetypes/getitems');
            }
        }
        this.asignationTypes = {
            //getItems: function () {
            //    return $http.get(baseUrl + 'asignationtypes/getitems');
            //},
            getItems: function (param) {
                return $http.post(baseUrl + 'asignationtypes/getitems', { Type: param });
            },
            getAllItems: function () {
                return $http.get(baseUrl + 'asignationtypes/getitems');
            }
        }
        this.objectAllocation = {
            save: function (params) {
                return $http.post(baseUrl + 'objectallocation/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'objectallocation/remove', params);
            },
            getItemsDetailByPerson: function (params) {
                return $http.get(baseUrl + 'objectallocation/getitemsdetailbyperson/' + params);
            },
            getItemsByWflPerson: function (params) {
                return $http.post(baseUrl + 'objectallocation/itemsbywflperson/', params);
            },
            /**
             * Devuelve las asignaciones del objeto.
             * @param {number} objectId Id del objeto.
             */
            getObjectAllocations: function (objectId) {
                return $http.get(baseUrl + 'objectallocation/getobjectallocations' +
                    '?objectId=' + (!!objectId ? objectId : -1));
            },
            /**
             * Devuelve una asignación por su Id
             * @param {number} allocationId Id de la asignación.
             */
            getAllocation: function (allocationId) {
                return $http.get(baseUrl +
                    'objectallocation/getitem/' + (!!allocationId ? allocationId : -1));
            }
        };

        this.reports = {
            //No tiene método en controller
            //getItemByFunc: function (funCode) {
            //    return $http.post(baseUrl + 'reports/getitembyfunc', { Code: funCode });
            //},
            save: function (report) {
                return $http.post(baseUrl + 'reports/save', report);
            },
            getPrivileges: function (rptId) {
                return $http.get(baseUrl + 'reportprivileges/getprivileges/' + rptId);
            },
            getAvailablePrivileges: function (rptId) {
                return $http.get(baseUrl + 'reportprivileges/getavailableprivileges/' + rptId);
            },
            assign: function (item) {
                return $http.post(baseUrl + 'reportprivileges/assign', item);
            },
            unassign: function (item) {
                return $http.post(baseUrl + 'reportprivileges/unassign', item);
            },
            getGroups: function (filter) {
                return $http.post(baseUrl + 'reports/getgroups', filter);
            },
            getItems: function () {
                return $http.get(baseUrl + 'reports/getitems');
            },
            getItemsByCode: function (code) {
                return $http.get(baseUrl + 'reports/getitemsbycode/' + code);
            },
            getItemsWithSecurity: function (code) {
                return $http.get(baseUrl + 'reports/getitemswithsecurity/' + code);
            },
            remove: function (report) {
                return $http.post(baseUrl + 'reports/remove', report);
            }
        }

        this.reportsNodes = {
            getNodes: function (filter) {
                return $http.post(baseUrl + 'reportsnodes/getnodes', filter);
            },
            save: function (node) {
                return $http.post(baseUrl + 'reportsnodes/save', node);
            },
            remove: function (node) {
                return $http.post(baseUrl + 'reportsnodes/remove', node);
            }
        }

        this.store = {
            deployWebApiExtension: function (deployInfo) {
                return $http.post(baseUrl + 'store/deploywebapiextension', deployInfo);
            },
            getExtensions: function (filter) {
                return $http.post(baseUrl + 'store/getextensions', filter);
            },
            getExtensionTypes: function () {
                return $http.get(baseUrl + 'store/getextensiontypes');
            },
            getExtensionGroups: function () {
                return $http.get(baseUrl + 'store/getextensiongroups');
            }
        }

        this.dialers = {
            getItems: function () {
                return $http.get(baseUrl + 'dialers/getitems');
            },
            getObjectCampaign: function (id) {
                return $http.get(baseUrl + 'dialers/getobjectcampaign/' + id);
            },
            getManualCampaignTelByPersonId: function (id) {
                return $http.get(baseUrl + 'dialers/getmanualcampaigntelbypersonid/' + id);
            },
            GetManualCampaignTelByAccountId: function (id) {
                return $http.get(baseUrl + 'dialers/GetManualCampaignTelByAccountId/' + id);
            },
            getCampaignByObjectCampaignId: function (id) {
                return $http.get(baseUrl + 'dialers/getmanualcampaignbyobjectcampaign/' + id);
            },
            save: function (dialer) {
                return $http.post(baseUrl + 'dialers/save', dialer);
            },
            activate: function (dialer) {
                return $http.post(baseUrl + 'dialers/activate', dialer);
            },
            getActiveDialer: function () {
                return $http.get(baseUrl + 'dialers/getactivedialer');
            }
        }

        this.smtp = {
            getConfig: function () {
                return $http.get(baseUrl + 'smtp/getconfig');
            },
            save: function (smtp) {
                return $http.post(baseUrl + 'smtp/save', smtp);
            }
        }

        this.emailSender = {
            send: function (id) {
                return $http.get(baseUrl + 'emailsender/send/' + id);
            },
            create: function (email) {
                return $http.post(baseUrl + 'emailsender/create', email);
            }
        }

        this.maintenance = {
            getServerState: function () {
                return $http.get(baseUrl + 'maintenance/getserverstate/');
            }
        }

        this.suspension = {
            getItem: function (params) {
                return $http.get(baseUrl + 'suspension/GetItem/' + params);
            }
            , getItemsByPerson: function (params) {
                return $http.get(baseUrl + 'suspension/GetItemsByPerson/' + params);
            }
            , getDependencies: function (params) {
                return $http.get(baseUrl + 'suspension/GetDependencies/' + params);
            }
            , save: function (param) {
                return $http.post(baseUrl + 'suspension/save', param);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'suspension/Remove', params);
            }
            , getItemsByWflPerson: function (params) {
                return $http.post(baseUrl + 'suspension/itemsbywflperson', params);
            }
        }

        this.directives = {
            getItem: function (params) {
                return $http.get(baseUrl + 'directives/GetItem/' + params);
            }
            , getItems: function () {
                return $http.get(baseUrl + 'directives/GetItems');
            }
            , GetItemsByGroup: function (params) {
                return $http.get(baseUrl + 'directives/GetItemsByGroup/' + params);
            }
            , save: function (param) {
                return $http.post(baseUrl + 'directives/save', param);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'directives/Remove', params);
            }
        }
        this.metParameter = {
            getItemsByHeaderCode: function (code) {
                return $http.get(baseUrl + 'metparametersdetail/getitemsbyheadercode/' + code);
            }
            , save: function (param) {
                return $http.post(baseUrl + 'metparametersdetail/save', param);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'metparametersdetail/remove', params);
            }
            , delete: function (params) {
                return $http.post(baseUrl + 'metparametersdetail/erase', params);
            }

            , GetEntitiesByHeaderCode: function (code) {
                return $http.get(baseUrl + 'metparametersdetail/GetEntitiesByHeaderCode/' + code);
            }
        }
        this.SubConcepts = {
            getItems: function () {
                return $http.get(baseUrl + 'SubConcepts/GetItems');
            }
            , getItem: function (params) {
                return $http.get(baseUrl + 'SubConcepts/GetItem/' + params);
            }
            , getItemByConcepts: function (code) {
                return $http.get(baseUrl + 'SubConcepts/GetItemByConcepts/' + code);
            }
            , getItemByCompany: function (id) {
                return $http.get(baseUrl + 'SubConcepts/getItemByCompany/' + id);
            }
            ,
            GetSubconceptsByPer: function (params) {
                return $http.post(baseUrl + 'SubConcepts/GetSubconceptsByPer', params);
            }
            ,
            getActionTypesGas: function (params) {
                return $http.post(baseUrl + 'SubConcepts/actionTypesGas', params);
            }
            , save: function (param) {
                return $http.post(baseUrl + 'SubConcepts/save', param);
            }
        }
        this.Concept = {
            getItems: function () {
                return $http.get(baseUrl + 'concept/GetAllItems');
            }
            , save: function (param) {
                return $http.post(baseUrl + 'concept/save', param);
            }
        }
        this.variableRate = {
            getItem: function (id) {
                return $http.get(baseUrl + 'rate/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'rate/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'rate/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'rate/remove', params);
            }
        }
        this.insurance = {
            getItem: function (id) {
                return $http.get(baseUrl + 'insurance/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'insurance/getitems/');
            },
            getItemsbyCompany: function (companyId) {
                return $http.get(baseUrl + 'insurance/getitemsbyCompany/' + companyId);
            },
            getItemsByType: function (id) {
                return $http.get(baseUrl + 'insurance/getitemsbytype/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'insurance/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'insurance/remove', params);
            }
        }

        this.insuranceType = {
            getItem: function (id) {
                return $http.get(baseUrl + 'InsuranceType/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'InsuranceType/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'InsuranceType/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'InsuranceType/remove', params);
            }
        }

        this.insuranceAliquot = {
            getItem: function (id) {
                return $http.get(baseUrl + 'InsuranceAliquot/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'InsuranceAliquot/getitems/');
            },
            getItemsFoo: function (params) {
                return $http.post(baseUrl + 'InsuranceAliquot/GetItemsFoo/', params);
            },
            getItemByInsurance: function (id) {
                return $http.get(baseUrl + 'InsuranceAliquot/getitembyinsurance/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'InsuranceAliquot/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'InsuranceAliquot/remove', params);
            }
        }

        this.honoraryType = {
            getItem: function (id) {
                return $http.get(baseUrl + 'HonoraryType/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'HonoraryType/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'HonoraryType/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'HonoraryType/remove', params);
            }
        }

        this.rateVariation = {
            getItem: function (id) {
                return $http.get(baseUrl + 'RateVariations/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'RateVariations/getitems/');
            },
            getItemsFoo: function (params) {
                return $http.post(baseUrl + 'RateVariations/GetItemsFoo/', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'RateVariations/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'RateVariations/remove', params);
            }
        }

        this.indexation = {
            getItem: function (id) {
                return $http.get(baseUrl + 'indexation/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'indexation/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'indexation/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'indexation/remove', params);
            }
        }

        this.indexationVariation = {
            getItem: function (id) {
                return $http.get(baseUrl + 'indexationVariation/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'indexationVariation/getitems/');
            },
            getItemsFoo: function (params) {
                return $http.post(baseUrl + 'indexationVariation/GetItemsFoo/', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'indexationVariation/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'indexationVariation/remove', params);
            }
        }

        this.metScore = {
            getItem: function (id) {
                return $http.get(baseUrl + 'metScore/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'metScore/getitems/');
            },
            getItemsByCode: function (id) {
                return $http.get(baseUrl + 'metScore/getItemsByCode/' + id);
            },
            getItemsForScore: function (param) {
                return $http.post(baseUrl + 'metScore/getItemsForScore', param);
            }
        }

        this.tramosScore = {
            getItem: function (id) {
                return $http.get(baseUrl + 'score/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'score/getitems/');
            },
            getItemsByCompany: function (id) {
                return $http.get(baseUrl + 'score/getItemsByCompany/' + id);
            }
        }

        this.DebtLongSection = {
            getItem: function (id) {
                return $http.get(baseUrl + 'debtLongSections/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'debtLongSections/getitems/');
            },
            getItemsByCompany: function (id) {
                return $http.get(baseUrl + 'debtLongSections/getItemsByCompany/' + id);
            }
        }

        this.typePayBranch = {
            getItem: function (id) {
                return $http.get(baseUrl + 'mettypepaybranch/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'mettypepaybranch/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'mettypepaybranch/save', params);
            },
        }

        this.payBranch = {
            getItem: function (id) {
                return $http.get(baseUrl + 'metpaybranch/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'metpaybranch/getitems/');
            },
            getItemsByType: function (id) {
                return $http.get(baseUrl + 'metpaybranch/getitemsbytype/' + id);
            },
        }

        this.empPayBranch = {
            getItem: function (id) {
                return $http.get(baseUrl + 'paybranchcompany/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'paybranchcompany/getitems/');
            },
            GetItemsByPayBranch: function (param) {
                return $http.post(baseUrl + 'paybranchcompany/getitemsbypaybranch', param);
            },
            save: function (params) {
                return $http.post(baseUrl + 'paybranchcompany/save', params);
            }
        }

        this.tokenTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'tokentypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'tokentypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'tokentypes/save', params);
            }
        }

        this.tokens = {
            getItem: function (id) {
                return $http.get(baseUrl + 'token/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'token/getitems/');
            },
            getItemsByType: function (id) {
                return $http.get(baseUrl + 'token/getitemsbytype/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'token/save', params);
            }
        }

        this.AllocationHistory = {
            getItemsDetailByPerson: function (params) {
                return $http.get(baseUrl + 'allocationHistory/getitemsdetailbyperson/' + params);
            },
            getItemsByWflPerson: function (params) {
                return $http.post(baseUrl + 'allocationHistory/itemsbywflperson/', params);
            },
            /**
             * Retorna las asignaciones del objeto, paginadas.
             * @param {number} objectId Id de objeto.
             * @param {number} pageNumber Número de página.
             * @param {number} pageSize Cantidad de registros por página.
             */
            getPaginatedItemsByObject: function (objectId, pageNumber, pageSize) {
                var params = {
                    ObjectId: !!objectId ? objectId : -1,
                    PageNumber: !!pageNumber ? pageNumber : 0,
                    PageSize: !!pageSize ? pageSize : 3
                };
                return $http.post(baseUrl + 'allocationHistory/itemsbywflperson/', params);
            }
        }

        this.BlackList = {
            getItem: function (id) {
                return $http.get(baseUrl + 'blacklist/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'blacklist/getitems/');
            },
            getItemsByCompany: function (id) {
                return $http.get(baseUrl + 'blacklist/getItemsByCompany/' + id);
            },
            getItemsByCompanyAndFiliat: function (params) {
                return $http.post(baseUrl + 'blacklist/GetItemsByCompanyAndFiliat/', params);
            },
            importList: function (params) {
                return $http.post(baseUrl + 'blacklist/ImportList/', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'blacklist/save', params);
            },
        }

        this.encryptionType = {
            getItem: function (id) {
                return $http.get(baseUrl + 'encryptionType/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'encryptionType/getitems/');
            },
            getItemsByCompany: function (id) {
                return $http.get(baseUrl + 'encryptionType/getItemsByCompany/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'encryptionType/save', params);
            }
        }

        this.credentialTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'credentialTypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'credentialTypes/getitems/');
            },
            getItemByCode: function (id) {
                return $http.get(baseUrl + 'credentialTypes/getItemByCode/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'credentialTypes/save', params);
            }
        }

        this.chanelTypes = {
            getItem: function (id) {
                return $http.get(baseUrl + 'chanelTypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'chanelTypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'chanelTypes/save', params);
            }
        }
        // Versioned Software Apps (software)
        this.versionedSoftware = {
            getLastVersionSoftware: function () {
                return $http.get(baseUrl + 'versionedsoftware/GetCurrentVersionOfAllSoftware/');
            },
            getListVersionBySoftware: function (softwareCode) {
                return $http.get(baseUrl + 'versionedsoftware/GetItemsByTypeCode?softWareTypeCode=' + softwareCode);
            }
        };
        // Versioned Software Types
        this.versionedSoftwareTypes = {
            getTypes: function () {
                return $http.get(baseUrl + 'versionedsoftwaretypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'versionedsoftwaretypes/save', params);
            }
            , remove: function (params) {
                return $http.post(baseUrl + 'versionedsoftwaretypes/remove', params);
            }
        }


        this.credentials = {
            getCredential: function (id) {
                return $http.get(baseUrl + 'credential/getCredential/' + id);
            },
            getCredentialDecrypt: function (id) {
                return $http.get(baseUrl + 'credential/getCredentialDecrypt/' + id);
            },
            getCredentials: function () {
                return $http.post(baseUrl + 'credential/GetCredentials/');
            },
            getCredentialByType: function (id) {
                return $http.get(baseUrl + 'credential/getCredentialByType/' + id);
            },
            getCredentialByEncryptedType: function (id) {
                return $http.get(baseUrl + 'credential/getCredentialByEncryptedType/' + id);
            },
            getCredentialByIdentifier: function (id) {
                return $http.get(baseUrl + 'credential/getCredentialByIdentifier/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'credential/save', params);
            },
            saveEncrypted: function (params) {
                return $http.post(baseUrl + 'credential/saveEncrypted', params);
            },
            removeById: function (id) {
                return $http.get(baseUrl + 'credential/removeById/' + id);
            },
            ChangeState: function (params) {
                return $http.post(baseUrl + 'credential/ChangeState', params);
            }
        };

        this.credentialsAssignment = {
            getItem: function (id) {
                return $http.get(baseUrl + 'credentialAssignment/getItem/' + id);
            },
            getCredentialDetails: function (id) {
                return $http.get(baseUrl + 'credentialAssignment/GetCredentialDetails/' + id);
            },
            SaveUsers: function (params) {
                return $http.post(baseUrl + 'credentialAssignment/SaveUsers', params);
            },
            SaveTeams: function (params) {
                return $http.post(baseUrl + 'credentialAssignment/SaveTeams', params);
            },
            save: function (params) {
                return $http.post(baseUrl + 'credentialAssignment/save', params);
            }
        };
        this.proposalsType = {
            getItems: function () {
                return $http.get(baseUrl + 'proposalstype/getitems/');
            }
        },
            this.selfIndicators = {
                getReceipt: function (param) {
                    return $http.post(baseUrl + 'selfindicators/getreceipt', param);
                },
                getPhones: function (param) {
                    return $http.post(baseUrl + 'selfindicators/getphones', param);
                },
                getVouchers: function (param) {
                    return $http.post(baseUrl + 'selfindicators/getvouchers', param);
                },
                getRequisitions: function (param) {
                    return $http.post(baseUrl + 'selfindicators/getrequisitions', param);
                }
            }

        this.geographicZone = {
            getItem: function (id) {
                return $http.get(baseUrl + 'GeographZone/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'GeographZone/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'GeographZone/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'GeographZone/remove', params);
            }
        }
        this.genericParametric = {
            getItem: function (id) {
                return $http.get(baseUrl + 'ParametricEntity/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'ParametricEntity/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'ParametricEntity/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'ParametricEntity/remove', params);
            }
        }
        this.genericParametricValue = {
            getItem: function (id) {
                return $http.get(baseUrl + 'ParametricValueEntity/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'ParametricValueEntity/getitems/');
            },
            getItemsByParametric: function (id) {
                return $http.get(baseUrl + 'ParametricValueEntity/GetItemsByParametric/' + id);
            },
            save: function (params) {
                return $http.post(baseUrl + 'ParametricValueEntity/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'ParametricValueEntity/remove', params);
            }
        }
        this.ActionQuery = {
            getItem: function (id) {
                return $http.get(baseUrl + 'ActionQuery/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'ActionQuery/getitems/');
            },
            getAvailableActionQueriesForQuery: function (queryId) {
                return $http.get(baseUrl +
                    'actionquery/getavailableactionqueriesforquery?queryId=' + queryId);
            },
            getItemsByGroup: function () {
                return $http.get(baseUrl + 'ActionQuery/getitemsbygroup/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'ActionQuery/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'ActionQuery/remove', params);
            },
            /**
             * Indica si la acci�n de consulta est� siendo utilizada.
             * @param {any} id Id de acci�n de consulta.
             */
            actionQueryIsUsed: function (id) {
                var actionQueryId = !!id ? id : -1;
                return $http.get(baseUrl + 'actionquery/actionqueryisused?' + 'actionQueryId=' + actionQueryId);
            }
        };
        this.QueryActionType = {
            getItem: function (id) {
                return $http.get(baseUrl + 'QueryActionTypes/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'QueryActionTypes/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'QueryActionTypes/save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'QueryActionTypes/remove', params);
            }
        };

        this.dataTypes = {
            /**
             * Retorna los tipos de datos para los par�metros y los atributos de entidad.
             * */
            getItems: function () {
                return $http.get(baseUrl + 'datatypes/getitems');
            }
        };
        this.MetSearch = {
            getmetsearchs: function () {
                return $http.get(baseUrl + 'MetSearch/GetMetSearchs/');
            },
            getmetsearchsbycore: function (code) {
                return $http.get(baseUrl + 'MetSearch/GetMetSearchsByCore/' + code);
            },
            getmetsearchtype: function (type) {
                return $http.get(baseUrl + 'MetSearch/GetMetSearchByType/' + type);
            }
        };
        this.Consequents = {
            getItem: function (id) {
                return $http.get(baseUrl + 'Consequents/getitem/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'Consequents/getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'Consequents/save', params);
            },
            clone: function (params) {
                return $http.post(baseUrl + 'Consequents/Clone', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'Consequents/remove', params);
            },
            getItemsByActType: function (id) {
                return $http.get(baseUrl + 'Consequents/getitemsbyacttype/' + id);
            },
            getItemsFilterActRep: function (id) {
                return $http.get(baseUrl + 'Consequents/getitemsfilteractrep/' + id);
            },
            getItemsByEveType: function (id) {
                return $http.get(baseUrl + 'Consequents/getitemsbyevetype/' + id);
            },
            GetItemsByResponseType: function (id) {
                return $http.get(baseUrl + 'Consequents/GetItemsByResponseType/' + id);
            },
            getDllProperties: function () {
                return $http.get(baseUrl + 'consequents/getDllProperties');
            }
        };
        this.MetConsecuentStore = {
            getItems: function () {
                return $http.get(baseUrl + 'MetConsecuentStore/Getitems/');
            },
            getItemByCode: function (code) {
                return $http.get(baseUrl + 'MetConsecuentStore/GetItemByCode/' + code);
            },
            save: function (params) {
                return $http.post(baseUrl + 'MetConsecuentStore/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'MetConsecuentStore/Remove', params);
            }
        };

        this.brands = {
            /**
             * Retorna las marcas de la persona indicada, que no estén dadas de baja.
             * @param {number} personId Id de la persona.
             */
            getPersonBrands: function (personId) {
                return $http.get(baseUrl +
                    'brands/getpersonbrands?personId=' + (!!personId ? personId : -1));
            },
            /**
             * Retorna las marcas del objeto de gestion y workflows indicados, que no estén dados de baja.
             * @param {number} workflowId Id deworkflow.
             * @param {number} managementObjectId Id de objeto de gestión.
             */
            getObjectBrands: function (workflowId, managementObjectId) {
                return $http.get(baseUrl + 'brands/getobjectbrands' +
                    '?workflowId=' + (!!workflowId ? workflowId : -1) +
                    '&managementObjectId=' + (!!managementObjectId ? managementObjectId : -1));
            },
            save: function (params) {
                return $http.post(baseUrl + 'brands/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'brands/Remove', params);
            }
        };

        this.brandTypes = {
            getItems: function () {
                return $http.get(baseUrl + 'BrandType/Getitems/');
            },
            getItemsByEntity: function (code) {
                return $http.get(baseUrl + 'BrandType/GetItemsByEntity/' + code);
            },
            getWorkflowByEntity: function () {
                return $http.get(baseUrl + 'BrandType/GetWorkflows/');
            },
            getBrandTypeByWfl: function (code) {
                return $http.get(baseUrl + 'BrandType/GetBrandTypeByWfl/' + code);
            },
            save: function (params) {
                return $http.post(baseUrl + 'BrandType/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'BrandType/Remove', params);
            },
            GetBrandTypeByWflAndType: function (id) {
                return $http.get(baseUrl + 'BrandType/GetBrandTypeByWflAndType/' + id);

            },
            getItemBycode: function (code) {
                return $http.get(baseUrl + 'BrandType/GetItemBycode/' + code);
            }
        }

        this.managementObject = {
            /**
             * Retorna las transiciones del objeto habilitadas para el usuario logueado.
             * @param {number} objectId Id de objeto.
             */
            getObjectStateTransitions: function (objectId) {
                return $http.get(baseUrl + 'managementobject/getobjectstatetransitions' +
                    '?objectId=' + (!!objectId ? objectId : -1));
            },
            /**
             * Devuelve los cambios provocados en objeto.
             * @param {number} objectId Id de objeto.
             */
            getObjectChanges: function (objectId) {
                return $http.get(baseUrl + 'managementobject/getobjectchanges' +
                    '?objectId=' + (!!objectId ? objectId : -1));
            }
        };

        this.QueryEntities = {
            GetItemsByEntityAndType: function (param) {
                return $http.post(baseUrl + 'QueryEntityDetail/GetItemsByEntityAndType', param);
            },
            getItemsByEntity: function (id) {
                return $http.get(baseUrl + 'QueryEntityDetail/GetQueriesByEntity/' + id);
            },

            saveRule: function (params) {
                return $http.post(baseUrl + 'QueryEntity/CreateRule', params);
            },
            cloneRule: function (params) {
                return $http.post(baseUrl + 'QueryEntity/CloneRule', params);
            },
            updateQuery: function (id) {
                return $http.post(baseUrl + 'QueryEntity/updaterulequery', { Id: id });
            },
            preview: function (id) {
                return $http.get(baseUrl + 'QueryEntity/preview/' + id);
            },
            createRuleFromFilters: function (params) {
                return $http.post(baseUrl + 'QueryEntity/createfromfilters', params);
            },
            saveAll: function (params) {
                return $http.post(baseUrl + 'QueryEntity/saveAll', params);
            },
            removeAll: function (params) {
                return $http.post(baseUrl + 'QueryEntity/removeAll', params);
            },
            removeAllById: function (id) {
                return $http.post(baseUrl + 'QueryEntity/removeAllById', { Id: id });
            },
            pasteFilters: function (params) {
                return $http.post(baseUrl + 'QueryEntity/copy', params);
            },
            saveOrder: function (params) {
                return $http.post(baseUrl + 'QueryEntity/saveorder', params);
            }
        };

        this.sortFieldsByCampaing = {
            getItem: function (id) {
                return $http.get(baseUrl + 'SortFieldsByCampaing/Getitem/' + id);
            },
            getItemsByManualCampaign: function (id) {
                return $http.get(baseUrl + 'SortFieldsByCampaing/getItemsByManualCampaign/' + id);
            },
            getAtrributesByManualCampaign: function (id) {
                return $http.get(baseUrl + 'SortFieldsByCampaing/GetAtrributesByManualCampaign/' + id);
            },
            getItems: function () {
                return $http.get(baseUrl + 'SortFieldsByCampaing/Getitems/');
            },
            save: function (params) {
                return $http.post(baseUrl + 'SortFieldsByCampaing/Save', params);
            },
            remove: function (params) {
                return $http.post(baseUrl + 'SortFieldsByCampaing/Remove', params);
            }
        }

        this.viewAttachments = {
            getItemsFilter: function (params) {
                return $http.post(baseUrl + 'viewAttachments/GetItemsFilter', params);
            },
            getItem: function (id) {
                return $http.get(baseUrl + 'viewAttachments/getitem/' + id);
            }
        }

    }]);
