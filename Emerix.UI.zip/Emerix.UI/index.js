'use strict';

/* Controllers */

angular.module('app.controllers', ['ngCookies', 'ui.router'])
    .controller('AppCtrl', ['$rootScope', '$scope', '$localStorage', '$window', '$http', 'webApi', '$state', 'securityService', 'diagnostics', 'hubService', '$interpolate', '$location', 'redirectService', 'queryContextService',
        function ($rootScope, $scope, $localStorage, $window, $http, webApi, $state, securityService, diagnostics, hubService, $interpolate, $location, redirectService, queryContextService) {
            // add 'ie' and 'smart' classes to html
            var isIE = !!navigator.userAgent.match(/MSIE/i);
            isIE && angular.element($window.document.body).addClass('ie');
            isSmartDevice($window) && angular.element($window.document.body).addClass('smart');
            angular.element($window.document.body).addClass('smart'); // prueba para solucion con issue en apk

            $scope.getFunctionStartUpName = function (functionStartup) {
                var name = functionStartup;
                var match = /^([a-zA-Z0-9._\-]+)/i.exec(functionStartup);
                if (match) {
                    name = match[1];
                }
                return name;
            }
            $scope.setActive = function (item) {
                if (item.Children.length == 0)
                    $scope.Selected = $scope.getFunctionStartUpName(item.FunctionStartUp);
                //$scope.Selected = item;
            }
            // config
            $rootScope.app = {
                name: '\u00E9' + 'merix',
                title: '\u00E9' + 'merix',
                version: '6.4.2.4',
                versionUpdate: new Date(),
                apiUrl: 'https://apideveloper.santander.cl/sancl/privado/account_recovery/v1/scj-emerix/',
                user: {},
                settings: {
                    startupState: 'app.startup',
                    loginState: 'app.login',
                    defaultLangKey: 'es',
                    defaultSchema: { DbSchema: 'operacional' },
                    //defaultDatabase: 'Default',
                    navbarHeaderColor: 'bg-white-only',
                    navbarCollapseColor: 'bg-white-only',
                    asideColor: 'bg-black',
                    headerFixed: true,
                    asideFixed: false,
                    asideFolded: false,
                    asideDock: false,
                    container: false,
                    logout: true
                },
                businessModelId: 'per',
                businessModels: [
                    { id: 'per', name: 'Personas' },
                    { id: 'mn2', name: 'Modelo de negocio 2' }
                ],
                persons: [
                    {}
                ],
                isLoginSso: false,
                logoutvisible: true
            }

            // save settings to local storage
            if (angular.isDefined($localStorage.settings)) {
                //Clear ls sso
                if (angular.isDefined($localStorage.settings.token)) {
                    $localStorage.settings.channel_id = undefined;
                    $localStorage.settings.token = undefined;
                }
                for (var setting in $scope.app.settings) {
                    if (!$localStorage.settings.hasOwnProperty(setting)) {
                        $localStorage.settings[setting] = $scope.app.settings[setting];
                    }
                }
                $scope.app.settings = $localStorage.settings;
            } else {
                $rootScope.app.settings.loginState = ($location.$$path === '/app/loginsso') ? 'app.loginsso' : 'app.login';
                $localStorage.settings = $scope.app.settings;
            }

            // Navigation Audit
            diagnostics.startNavigationAudit();

            //Handle authentication
            securityService.authenticate(appStart, webApi)

            $rootScope.$on('unauthorized', function () {
                securityService.gotoLogin();
            });

            //Server under maintenance
            $rootScope.$on('maintenance', function (event, args) {
                securityService.gotoLogin();
                $rootScope.isUnderMaintenance = true;
            });

            $rootScope.$on('authenticated', appStart);

            $rootScope.$on('$stateChangeStart', function (e, to, toParams, from, fromParams) {
                if (!$rootScope.app.user.functions || $rootScope.app.settings.startupState == to.name)
                    return;
                var result = false;
                if (to.name == $rootScope.app.settings.startupState
                    || to.name === 'app.login'
                    || to.name === 'app.logout'
                    || to.name === 'app.loginsso'
                    || to.name === 'app.startup'
                    || to.name === 'app.footableFilterError'
                    || to.name === 'app.profile'
                    || to.name === 'app.aboutapp')
                    result = true;

                if (!result) {
                    //se puede limitar funcions solo con los que tienen FunctionStartUp
                    for (var i = 0; i < $rootScope.app.user.functions.length; i++) {
                        var item = $rootScope.app.user.functions[i];
                        var name = $scope.getFunctionStartUpName(item.FunctionStartUp);
                        //if (item.FunctionStartUp !== '' && item.FunctionStartUp === to.name) {
                        if (name !== '' && name === to.name) {
                            result = true;
                            break;
                        }
                    }
                }

                if (!result)
                    e.preventDefault();
            });


            //webApi.security.checkLicense().then(function (results) {
            //      $rootScope.licenseMessage = '';
            //      $rootScope.licenseMessage = results.data;
            //      if ($rootScope.licenseMessage.length > 0)
            //          $rootScope.$broadcast('technical_error', { message: $rootScope.licenseMessage });
            //
            //}, function (error) {
            //      var msg = error.data.ExceptionMessage;
            //      $rootScope.$broadcast('validation_error', { message: msg });
            //  });

            // Handle Methods
            $rootScope.$on('methodLoginSSO', function () {

                // checkLicense Method
                webApi.security.checkLicense().then(function (results) {
                    $rootScope.licenseMessage = '';
                    $rootScope.licenseMessage = results.data;
                    if ($rootScope.licenseMessage.length > 0)
                        $rootScope.$broadcast('technical_error', { message: $rootScope.licenseMessage });

                }, function (error) {
                    var msg = error.data.ExceptionMessage;
                    $rootScope.$broadcast('validation_error', { message: msg });
                });

                // LastVersion Method
                webApi.versionedSoftware.getLastVersionSoftware().then(function (results) {
                    var ui__ = results.data.find(function (item) {
                        return item.VersionedSoftwareTypeCode === "E_UI";
                    });
                    $rootScope.app.version = ui__.LargeVersion;
                    $rootScope.app.versionUpdate = ui__.InstallationDate;
                });

                // Login Methods and DB Connections
                webApi.security.getDatabaseConnections().then(function (results) {
                    $rootScope.databases = results.data;
                    if ($rootScope.databases.length === 1) {
                        $localStorage.settings.defaultDatabase = $rootScope.databases[0];
                    }
                });

            });

            function appStart() {

                var authData = securityService.fromStorage();

                $rootScope.app.user.name = authData.Username;
                $rootScope.app.user.photo = authData.Photo;
                $rootScope.app.user.functions = authData.Functions;
                $rootScope.app.user.menus = authData.Menus;
                $rootScope.app.user.schema = authData.Schema ? authData.Schema.DbSchema : null;
                $rootScope.app.user.scope = authData.Scope || {};
                $rootScope.app.user.userscope = authData.UserScope || {};
                $rootScope.app.user.entityscope = authData.EntityScope || {};
                $rootScope.app.user.changePasswordEnabled = authData.ChangePasswordEnabled;
                $rootScope.app.user.chatEnabled = authData.ChatEnabled;
                // webApi.versionedSoftware.getLastVersionSoftware().then(function (results) {
                //     var ui__ = results.data.find(function (item) {
                //         return item.VersionedSoftwareTypeCode === "E_UI";
                //     });
                //     $rootScope.app.version = ui__.LargeVersion;
                // })
                var loadStates = function () {
                    $rootScope.app.settings.startupState = 'app.startup';
                    if ($rootScope.app.user.functions) {
                        var states = $rootScope.app.user.functions.filter(function (item) {
                            return item.FunctionPath && item.FunctionUrl && item.FunctionStartUp;
                        });

                        states.forEach(function (item) {
                            if (item.FunctionStartUp == authData.Schema.PageDefault) {
                                $rootScope.app.settings.startupState = authData.Schema.PageDefault;
                            }
                            var stateName = $scope.getFunctionStartUpName(item.FunctionStartUp);
                            if (!$state.get(stateName)) {
                                var options = {
                                    url: item.FunctionUrl,
                                    templateUrl: item.FunctionPath
                                }

                                switch (item.FunctionStartUp) {
                                    case 'app.dialerpopup':
                                        options.params = {
                                            id_object_campaign: { value: null, squash: true },
                                            id_person: { value: null, squash: true },
                                            num_doc: { value: null, squash: true },
                                            nro_client: { value: null, squash: true },
                                            last_name: { value: null, squash: true },
                                            first_name: { value: null, squash: true },
                                            id_account: { value: null, squash: true },
                                            clave_ext: { value: null, squash: true }
                                        }
                                        break;
                                }
                                //app.stateProvider.state(item.FunctionStartUp, options);
                                app.stateProvider.state(stateName, options);

                            }
                        });


                    }

                };

                loadStates();

                //Handle schemas
                if (authData.Schema) $rootScope.app.settings.defaultSchema = authData.Schema;
                $localStorage.settings = $scope.app.settings;


                //EMX0000 - 11531
                if ($rootScope.app.settings.loginState === 'app.loginsso') {
                    $rootScope.app.isLoginSso = true;
                    //$rootScope.app.logoutvisible = false;
                    $rootScope.databases = [];
                    $rootScope.databases.push('Emerix');
                    $localStorage.settings.defaultDatabase = $rootScope.databases[0];
                } else {
                    $rootScope.app.logoutvisible = true;
                    $rootScope.app.isLoginSso = false;
                    // Login Methods and DB Connections
                    webApi.security.getDatabaseConnections().then(function (results) {
                        $rootScope.databases = results.data;
                        if ($rootScope.databases.length === 1) {
                            $localStorage.settings.defaultDatabase = $rootScope.databases[0];
                        }
                    });
                }


                // management flow
                $rootScope.flow = { isopen: false };
                $rootScope.selectedFlow = $localStorage.settings.lastSelectedFlow;
                //webApi.workflows.getWorkflows().then(function (result) {
                //    $rootScope.flows = result.data;
                //});
                $rootScope.setFlow = function (flow) {
                    $localStorage.settings.lastSelectedFlow = flow.Name;
                    $rootScope.selectedFlow = flow.Name;
                    $rootScope.selectFlow = $scope.flows[flow.Id];
                    $rootScope.flow.isopen = !$scope.flow.isopen;

                    //TODO: Change management flow
                };

                // languages
                var langKey = 'es';
                if (angular.isDefined($localStorage.langKey)) {
                    langKey = $localStorage.langKey;
                    $http.defaults.headers.common['emerix-user-lang'] = $localStorage.langKey;
                }
                $http.defaults.headers.common['emerix-user-lang'] = langKey;

                /* EMX0000-11790: Restauro la carga original de las labels y messages hasta que est�n
                 * finalizados los cambios introducidos por loginSso.
                 * */
                if (!$localStorage.settings.logout) {

                    if (!$rootScope.app.params) {
                        $rootScope.app.params = $localStorage.params;
                    //    webApi.parameter.installation()
                    //        .then(function (results) {
                    //            $rootScope.app.params = results.data;

                    //            $window.localStorage.setItem('decimalPlaces', results.data.DecimalPlaces);

                    //            //$window.EmerixParams = {
                    //            //    params: $rootScope.app.params
                    //            //};
                    //        });
                    }

                    //if (!$rootScope.app.parameters) {
                    //    webApi.parameter.getItems()
                    //        .then(function (results) {
                    //            $rootScope.app.parameters = results.data;
                    //        });
                    //}

                    if (!$rootScope.app.labels) {
                        webApi.resources.getLabels(langKey)
                            .then(function (results) {
                                $rootScope.app.labels = results.data;
                            });
                    }

                    if (!$rootScope.app.messages) {
                        webApi.resources.getMessages(langKey)
                            .then(function (results) {
                                $rootScope.app.messages = results.data;
                            });
                    }
                }
               
                /* Fin EMX0000-11790 */

                //Connect signalR
                //hubService.start();

                //$rootScope.$state.go(data.Schema.PageDefault);
                //$rootScope.$state.go($rootScope.app.settings.startupState);
                redirectService.redirectOnce($rootScope.app.settings.startupState);
            };

            //Global exception handling
            $rootScope.$on('unhandled_exception', function (event, args) {
                $rootScope.globalMessage = args.message || args;
                $state.go('app.error');
            });

            // detect mobile
            function isSmartDevice($window) {
                var ua = $window['navigator']['userAgent'] || $window['navigator']['vendor'] || $window['opera'];
                // Checks for iOs, Android, Blackberry, Opera Mini, and Windows mobile devices
                return (/iPhone|iPod|iPad|Silk|Android|BlackBerry|Opera Mini|IEMobile/).test(ua);
            }

            $rootScope.$on("$stateChangeSuccess", function (event, toState, toParams, fromState, fromParams) {
                $rootScope.app.title = $rootScope.app.name;
                if ($rootScope.app.lastState != fromState) {
                    if (fromState.name == '') {
                        $rootScope.app.lastState = toState;
                    } else {
                        $rootScope.app.lastState = fromState;
                    }
                }

            });

            $rootScope.$watch('app.title', function (newValue, oldValue) {
                if (newValue != oldValue) {
                    var changeTitle = function (headItem) {
                        if (headItem.tagName.toLowerCase() == "title") {
                            headItem.text = $rootScope.app.title;
                        };
                    };
                    var documentHead = $window.document.head.children;
                    for (var i = 0; i < documentHead.length; i++) {
                        changeTitle(documentHead[i]);
                    }
                }
            });

            $rootScope.parser = function (stringValue) {
                var a = $interpolate("app.wfl_workflows({companyId:{{app.selectedCompanyId || 1}}, workflowId:{{app.selectedWorkflowId || 1}}})");

                var b = a({ cId: $rootScope.app.selectedCompanyId || 1, wId: $rootScope.app.selectedWorkflowId || 1 })

                return b;
            }

            if ($window.sessionStorage.toDoWaybills) {
                $rootScope.hasWaybills = true;
            }

            $scope.menuHasLink = function (item) {
                var retvalue = false;
                if (item.FunctionStartUp)
                    retvalue = true;
                if (!retvalue)
                    for (var i = 0; i < item.Children.length; i++) {
                        retvalue = $scope.menuHasLink(item.Children[i]);
                        if (retvalue) break;
                    }
                return retvalue;
            }
            $rootScope.$on('chatEnabled', function (event, enabled) {
                var ena = enabled;
                if ($rootScope.app.settings.defaultSchema.DbSchema && $rootScope.app.settings.defaultSchema.DbSchema != 'operacional') {
                    ena = false;
                }
                $rootScope.app.user.chatEnabled = ena;
            });

            securityService.setRefreshTokenInterval();
        }]);
